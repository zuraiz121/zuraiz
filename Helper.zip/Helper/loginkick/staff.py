# -*- coding: utf-8 -*-
# -*- Famz___Botz -*-
# -*- Version: CL_warnode V.01 2020-*-
# -*- Creator: Bardian_Syah -*-
from famzbotz.bardi import *
from akad.ttypes import *
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from threading import Thread
from Naked.toolshed.shell import execute_js
from multiprocessing import Pool, Process
from time import sleep
import time, random, multiprocessing, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, pafy, urllib, urllib.parse
from datetime import timedelta, date
from humanfriendly import format_timespan, format_size, format_number, format_length
from datetime import datetime
import html5lib
import requests,json,urllib3
from random import randint
import pyimgflip

_session = requests.session()
botStart = time.time()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=================================================================================#
appF = "DESKTOPMAC\t5.22.0\tHH-L1DDKK\t10.3"
#=================================================================================#
try:
    with open('token.txt','r') as tokens:
        token = tokens.read()
    print(str(token))
except Exception as e:
    line = LINE()
line= LINE(token,appName=appF)
line.log("Auth Token : " + str(line.authToken))
#=================================================================================#
oepoll = OEPoll(line)
lineProfile = line.getProfile()
lineSettings = line.getSettings()
mid = line.profile.mid
mid = line.getProfile().mid
print ("BOSS : " + mid)
print ("==========[[LOGIN SUCCES]]==========")
#=================================================================================#
creator = ["uaba85bd109b0575220c242cffb6efb8a"]
owner = ["uaba85bd109b0575220c242cffb6efb8a"]
admin = ["uaba85bd109b0575220c242cffb6efb8a"]
staff = ["uaba85bd109b0575220c242cffb6efb8a"]
Bots = [mid]
#=================================================================================#
Team = creator + owner + admin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

blacklist = []
targets = []
_dn = []
warmode = []
welcome = []
msg_dict = {}
msg_dict1 = {}

settings = {"Picture":False,"group":{},"groupPicture":False,"changePicture":False,"autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5","Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0","Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0","Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}
wait = {
    "limit": 1,
    "creator":{},
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "autoAdd":False,
    'autoJoin':False,
    'autoLeave':False,
    "protectqr":False,
    "protectinvite":False,
    "protectjoin":False,
    "protectkick":False,
    "protectantijs":False,
    "protectcancel":False,
    "jointicket":False,
    "qr":False,
    "Danger":False,
    "sangar":False,
    "selfbot":True,
    "Response":"We Are Famz1",
    "Cmdnuke":"banned",
    "comment":"ʟⁱᵏᵉ ʟⁱᵏᵉ & ʟⁱᵏᵉ ᴀʲᵃ - ʙʏ : famz__Botz",
    "comment1":"ʟⁱᵏᵉ ʟⁱᵏᵉ & ʟⁱᵏᵉ ᴀʲᵃ - ʙʏ : famz__Botz",
    "comment2":"ʟⁱᵏᵉ ʟⁱᵏᵉ & ʟⁱᵏᵉ ᴀʲᵃ - ʙʏ : famz__Botz",
    "message":"ᴛᴇʀɪᴍᴀᴋᴀsɪʜ sᴜᴅᴀʜ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ sᴀʏᴀ\nsᴇʙᴀɢᴀɪ ᴛᴇᴍᴀɴ ᴀɴᴅᴀ 😎😎😎.",
}
read = {"readPoint":{},"readMember":{},"readTime":{},"ROM":{},}
cctv = {"cyduk":{},"point":{},"sidermem":{}}
virr =""".1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.

 Hello!
3xploi7 BuG
.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J. Hello!
3xploi7 BuG
.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A."""
#=================================================================================#
helpMessage ="""     ⏭️⏭️ Famz___Botz ⏮️⏮️
╔═══════════════════╗
╠🇮🇩● help
╠🇮🇩● cekbot
╠🇮🇩● me
╠🇮🇩● mid
╠🇮🇩● midbots
╠🇮🇩● status
╠🇮🇩● refresh
╠🇮🇩● /hahaha
╠🇮🇩● set cmdnuke: [text]
╠🇮🇩● clean
╠🇮🇩● restart
╠🇮🇩● runtime
╠🇮🇩● absen
╠🇮🇩● out
╠🇮🇩● sp
╠🇮🇩● myfriend
╠🇮🇩● grouplist
╠🇮🇩● listbot
╠🇮🇩● Addadmin @
╠🇮🇩● listadmin
╠🇮🇩● myname: [nama]
╠🇮🇩● updatefoto
╠🇮🇩● all/tagall
╠🇮🇩● Kick @
╠🇮🇩● Vkick [nama]
╠
╠Remote CMD dari luar room
╠🇮🇩● grouplist
╠🇮🇩● baypass [nomor]
╠🇮🇩● inviteme [nomor]
╠🇮🇩● out [nomor]
╠🇮🇩● ambilqr [nomor]
╚═══════════════════╝"""

mulai = time.time()
tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
def logError(text):
    line.log("[ Bardian__Syah ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("famzbotz.txt","a") as error:
        error.write("\n[{}] {}".format(str(time), text))

def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.001)        
            page = page[end_content:]
    return items

def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def backupProfile():
    profile = line.getContact(mid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = line.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)

def backupData():
    try:
        backup1 = Setmain
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup1, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup2 = settings
        f = codecs.open('settings.json','w','utf-8')
        json.dump(backup2, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup3 = wait
        f = codecs.open('wait.json','w','utf-8')
        json.dump(backup3, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup4 = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup4, f, sort_keys=True, indent=4, ensure_ascii=False)        
        return True
    except Exception as error:
        logError(error)
        return False

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d ʜᴀʀɪ %02d ᴊᴀᴍ %02d ᴍᴇɴɪᴛ %02d ᴅᴇᴛɪᴋ' % (days, hours, mins, secs)

def famzMention(to, mids=[]):
    parsed_len = len(mids)//20+1
    result = '╭──「ᴍᴇɴᴛɪᴏɴ_ᴍᴇᴍʙᴇʀs」\n'
    mention = '>>> Famz__Botz <<<\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '│ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰──「ᴍᴇɴᴛɪᴏɴ_ᴍᴇᴍʙᴇʀs」'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
#-----------------------------------------AUTO__JOIN--------------------------------------------
        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:line.acceptGroupInvitation(op.param1)
                    else:line.acceptGroupInvitation(op.param1)
#-------------------------------------------------------------------------------------------------------------------------------
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        line.sendMessage(op.param1, wait["message"])

        if op.type == 55:
            try:
                if op.param1 in Setmain["famzreadPoint"]:
                   if op.param2 in Setmain["famzreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["famzreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
               try:line.kickoutFromGroup(op.param1,[op.param2])
               except:pass
                   
        if op.type ==  26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if wait ["Danger"] == True:
            	if msg._from not in Team:
                    if msg.text in [".js","!js",".sikat","!sikat","sikat","Bubar",".bubar","!bubar",".cipok","!cupok","Cleanse","!cleanse",".cleanse","Kickall","!kickall",".kickall","mayhem","Ratakan","bubarkan","Nuke","nuke",".nuke","Bypass","bypass",".bypass","hancurkan","!malam","winebot",".malam"]:
                        line.kickoutFromGroup(receiver,[sender])

        if op.type == 25 or op.type == 26:
            print ("[25/26] Famz___Botz")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 1:
                 if msg._from in mid:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = line.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            line.sendMessage(msg.to, "✓Berhasil Menambahkan Gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.contentType == 1:
                   if msg._from in mid:
                       if mid in Setmain["famzfoto"]:
                            path = line.downloadObjectMsg(msg_id)
                            del Setmain["famzfoto"][mid]
                            line.updateProfilePicture(path)
                            line.sendMessage(msg.to, "✓ᴘʀᴏғɪʟᴇ ᴘʜᴏᴛᴏ\nsᴜᴄᴄᴇssғᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ")
                     
               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        line.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                    #    if cmd == str(msg.text):
                     #     if wait["selfbot"] == True:
                     #       if msg._from in mid:
                     #           s = cmd[:1]
                     #           for a in s:
                     #               if s in "abcdefghijklmnopqrstuvwxyz":
                     #                   x = line.getGroup(msg.to)
                     #                   anu = x.id
                     #                   targets = []
                     #                   nami = [contact.mid for contact in x.members]
                     #                   targetk = []
                     #                   for a in nami:
                     #                       if a not in creator and a not in owner:
                     #                           targetk.append(a)
                     #                   cms = 'kick.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                     #                   for y in targetk:
                     #                       cms += ' uik={}'.format(y)
                     #                   print(cms)
                       #                 success = execute_js(cms)

                        if cmd.startswith("a"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("b"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("c"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("d"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("e"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("f"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("g"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("h"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("."):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("+"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("@"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("#"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("&"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("*"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith(":"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("$"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith(")"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("-"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("i"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("j"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("k"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("l"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("m"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("n"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("o"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("p"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("q"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("r"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("s"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("t"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("u"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("v"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("w"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("x"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("y"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)

                        if cmd.startswith("z"):
                          if wait["selfbot"] == True:
                            if msg._from in mid:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                targets = []
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                for a in nami:
                                    if a not in creator and a not in owner:
                                        targetk.append(a)
                                cms = 'style.js gid={} token={} app={}'.format(anu,line.authToken,appF)
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                print(cms)
                                success = execute_js(cms)







                        elif ("/ti/g/" in msg.text):
                            if wait["jointicket"] == True:
                                link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                links = link_re.findall(text)
                                n_links = []
                                for l in links:
                                    if l not in n_links:
                                        n_links.append(l)
                                for ticket_id in n_links:
                                    group = line.findGroupByTicket(ticket_id)
                                    line.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    line.sendMessage(msg.to, "Bots Berhasil Join Link QR")
                                  


    except Exception as error:
        print (error)
while True:
    try:
      ops=oepoll.singleTrace(count=50)
      if ops != None:
        for op in ops: 
          bot(op)
          oepoll.setRevision(op.revision)
    except Exception as e:
        print(e)
