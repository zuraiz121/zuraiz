const thrift = require('thrift-http');
const LineService = require('LineService');

var _client = '';
var gid = '';
var uids = [];
var cancel = [];
var invite = [];
var token = '';

process.argv.forEach(function (val) {
  if(val.includes('gid=')){
    gid = val.split('gid=').pop();
  }else if(val.includes('uid=')){
    uids.push(val.split('uid=').pop());
  }else if(val.includes('cid=')){
    cancel.push(val.split('cid=').pop());
  }else if(val.includes('uik=')){
    invite.push(val.split('uik=').pop());
  }else if(val.includes('token=')){
    token = val.split('token=').pop();
  }
});

function setTHttpClient(options) {
    var connection =
      thrift.createHttpConnection('legy-jp-addr-long.line.naver.jp', 443, options);
    connection.on('error', (err) => {
      console.log('err',err);
      return err;
    });
    _client = thrift.createHttpClient(LineService, connection);
  }


setTHttpClient(options={
    protocol: thrift.TCompactProtocol,
    transport: thrift.TBufferedTransport,
    headers: {'User-Agent':'Line/10.15.2','X-Line-Application':"DESKTOPMAC\t5.24.1\tMac Os\t10.15.2",'X-Line-Access':token},
    path: '/S4',
    https: true
    });


async function func1() {

  let promise1 = new Promise((resolve, reject) => {
    try {
    for (var i=0; i < uids.length; i++) {
      _client.kickoutFromGroup(0, gid, [uids[i]]);
    }
    resolve("Kick Done")
    } catch(e) {
    reject(e);
    }
  });
  return promise1;
}

async function func2() {

  let promise2 = new Promise((resolve, reject) => {
    try {
    for (var i=0; i < cancel.length; i++) {
      _client.cancelGroupInvitation(0, gid, [cancel[i]]);
    }
    resolve("Cancel Done")
    } catch(e) {
    reject(e);
    }
  });
  return promise2;
}

async function func3() {

  let promise3 = new Promise((resolve, reject) => {
    try {
    _client.inviteIntoGroup(0,gid,invite);
    resolve("Invite Done")
    } catch(e) {
    reject(e);
    }
  });
  return promise3;
}



var promise1 = func1();
var promise2 = func2();
var promise3 = func3();
Promise.all([promise1, promise2, promise3])
  .then(results => console.log(results));
