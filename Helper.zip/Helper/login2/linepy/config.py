# -*- coding: utf-8 -*-
from akad.ttypes import ApplicationType
import re, codecs, json
ranaOpen = codecs.open("rana.json","r","utf-8")
ranagg = json.load(ranaOpen)

class Config(object):
    LINE_HOST_DOMAIN = f"{ranagg['userDomain']}"
    LINE_OBS_DOMAIN = 'https://obs.line-apps.com'
    LINE_TIMELINE_API = LINE_HOST_DOMAIN + '/mh/api'
    LINE_TIMELINE_MH = LINE_HOST_DOMAIN + '/mh'
    LINE_LIFF_SEND = 'https://api.line.me/message/v3/share'
    LINE_PERMISSION_API = 'https://access.line.me/dialog/api/permissions'
    LINE_LOGIN_QUERY_PATH = '/api/v4p/rs'
    LINE_AUTH_QUERY_PATH = '/api/v4/TalkService.do'
    LINE_SECONDARY_PATH = "/acct/lgn/sq/v1"
    LINE_SECONDARY_PERMIT_PATH = "/acct/lp/lgn/sq/v1"
    LINE_API_QUERY_PATH_FIR = '/S4'
    LINE_POLL_QUERY_PATH_FIR = '/P4'
    LINE_CALL_QUERY_PATH = '/V4'
    LINE_LIFF_QUERY_PATH = '/LIFF1'
    LINE_CERTIFICATE_PATH = '/Q'
    LINE_CHAN_QUERY_PATH = '/CH4'
    LINE_SQUARE_QUERY_PATH = '/SQS1'
    LINE_SHOP_QUERY_PATH = '/TSHOP4'

    CHANNEL_ID = {
        'LINE_TIMELINE': '1341209850',
        'LINE_WEBTOON': '1401600689',
        'LINE_TODAY': '1518712866',
        'LINE_STORE': '1376922440',
        'LINE_MUSIC': '1381425814',
        'LINE_SERVICES': '1459630796'
    }

    APP_TYPE = ApplicationType._VALUES_TO_NAMES[368]
    CARRIER = '51089, 1-0'
    IP_ADDR = '8.8.8.8'
    SYSTEM_NAME = 'TheVsPm'
    EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")

    def __init__(self, appType=None):
        angntapp = f"ranagg['userapp']"
        lapp = ranagg['userappname'].split("\t")
        _appt = lapp[0]
        _appv = lapp[1]
        _apps = lapp[2]
        _appsv = lapp[3]
        self.APP_VER = lapp[1]
        self.APP_NAME = '%s\t%s\t%s\t%s' % (_appt, _appv, _apps, _appsv)
        self.USER_AGENT = angntapp

#CARRIER = '44010, 1-0'