from .session import Session
from .e2ee import E2EE
from akad.ttyper import *

class Secondary(object):
    def __init__(self):
        self.host = "https://legy-jp.line.naver.jp"
        self.path = "/acct/lgn/sq/v1"
        self.path2 = "/acct/lp/lgn/sq/v1"

    def generateQrCode(self, application: str):
        app = application.split("\t")
        if app[0] != "ANDROIDLITE":
            user_agent = "Line/%s" % str(app[1])
        else:
            user_agent = "LLA/%s" % str(app[1])
        
        Headers = {
            "X-Line-Application": application,
            "User-Agent": user_agent
        }

        print(Headers)

        self.secondary = Session(self.host, Headers, self.path).Qr()
        
        session = self.secondary.createSession(CreateQrSessionRequest()).authSessionId
        e2ee = E2EE()
        qrcode = self.secondary.createQrCode(CreateQrCodeRequest(session)).callbackUrl + e2ee.generateParams()
        print("URL : " + str(qrcode))

        Headers = {
            "X-Line-Application": application,
            "User-Agent": user_agent,
            "X-Line-Access": session
        }

        self.permit = Session(self.host, Headers, self.path2).Permit()

        self.permit.checkQrCodeVerified(CheckQrCodeVerifiedRequest(session))
        try:
            self.secondary.verifyCertificate(VerifyCertificateRequest(session, None))
        except:
            pincode = self.secondary.createPinCode(CreatePinCodeRequest(session)).pinCode
            print("PIN CODE :", pincode)
            self.permit.checkPinCodeVerified(CheckPinCodeVerifiedRequest(session))
        result = self.secondary.qrCodeLogin(QrCodeLoginRequest(session, app[2], True))
        return result