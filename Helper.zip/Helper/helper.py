# BOT LOGIN
#UPDATED BY TEAM KB
from LineAPI.linepy import *
from v1 import BEAPI
from spminfo import shahzi
from LineAPI.akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from LineAPI.akad.ttypes import ContentType as Type
from LineAPI.akad.ttypes import TalkException
from KhieBots.thrift.protocol import TCompactProtocol
from KhieBots.thrift.transport import THttpClient
from KhieBots.ttypes import LoginRequest
from Naked.toolshed.shell import execute_js
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser
from time import sleep
import livejson
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from threading import Thread
from Naked.toolshed.shell import execute_js
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
from threading import Thread, activeCount
import LineService
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
appF = "DESKTOPMAC\t7.3.1\tmacOS\t11.6"
#=====================================================================

noobcoder = LINE("zuraizkha678@gmail.com","Zuraiz77" ,appName="DESKTOPMAC\t7.3.1\tmacOS\t11.6")
#noobcoder = LINE("killmsjglacier@gmail.com","ZURAIZ143",appName="DESKTOPMAC\t7.3.1\tmacOS\t11.6")
try:
    Channel(noobcoder, "1597127494").getChannelResult().channelAccessToken
except:pass
try:
    Channel(noobcoder, "1655838636").getChannelResult().channelAccessToken
except:pass
try:
    Channel(noobcoder, "1638870522").getChannelResult().channelAccessToken
except:pass
#=======================================================
waitOpen = codecs.open("noobcoder/wait.json","r","utf-8")
settingsOpen = codecs.open("noobcoder/temp.json","r","utf-8")
premiumOpen = codecs.open("noobcoder/user.json","r","utf-8")
#aadminOpen = codecs.open("noobcoder/aadmin.json","r","utf-8")
loggingmodOpen = codecs.open("database.json","r","utf-8")
seensOpen = codecs.open("lastseen.json","r","utf-8")
#=====================================================================
noobcoderProfile = noobcoder.getProfile()
noobcoderSettings = noobcoder.getSettings()
noobcoderPoll = OEPoll(noobcoder)
noobcoderMID = noobcoder.getProfile().mid
#=====================================================================
loop = asyncio.get_event_loop()
aadmin = livejson.File("noobcoder/aadmin.json",True,True,4)
kbkb = livejson.File("kbkb.json",True,True,4)
selfuser = livejson.File("noobcoder/user.json",True,True,4)
squad = kbkb['squad']
TURN_OFF_E2EE = False
banuser = kbkb['ban']
owner = aadmin["admins"]
buyer = aadmin["owners"]
seller = aadmin["sellers"]
kbkick = kbkb['kicker']
flexroom = kbkb['flexroom']
sblogin = selfuser['listLogin']
kick = {"auto":False,"kicker":{}}
creator = ["uffcbe9d2c8ce887df554188b17937986"]
lastall = {"auto":False,"lkick":{},"lcancel":{},"lleave":{},"linvite":{},"ljoin":{},"lban":"","lcon":{}}
botStart = time.time()
msg_dict = {}
temp_flood = {}
groupName = {}
groupImage = {}
khiewuzz = {}
protectantijs = []
wbanlist = []
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
premium = json.load(premiumOpen)
seens = json.load(seensOpen)
log = json.load(loggingmodOpen)

bye = {
    "byee": " See you Next Time \n Bye Bye Friends"
}
welcome = {
    "welcomee": "welcome to the family group."
}

setbot = {
    "separator": "#C1C1C1",
    "broadcastcolor": "#00FFFF",
    "textcolor": "#ffff00",
    "background": "#000000",
    "brandname": "👑 ZURAIZPOWER👑"
}
AppLiff = {
    "app": "1597127494-QDP2OlYl",
}

tailah = {
    "siderTemp": {},
    "siderPesan": "Oh Hi",
}

flex = {
    "flex": True,
    "chat": False
}

tailah1 = {
    "siderTemp": {},
    "siderPesan": "Oh Hi",
}

tailah2 = {
    "siderTemp": {},
    "siderPesan": "Oh Hi",
}

sniffin = {
        "sniff": [],
}
hoho = {
    "savefile": False,
    "namefile": "",
}
add = {
    "addfriend": False,
}

tempe = {
    "msg": True,
}

asu = {
    "noteNjer": False,
}

peler = { 
    "receivercount": 0,
    "sendcount": 0
}
mcroom = {
    "leaveMC": True,
}
chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}

read = { 
    "readMember": {},
    "readPoint": {}
}

khiewuzz = {'mimic':{},'text1':'','text2':'','msgid': {},'token':'','thread':{},'exdrawing':False,'puzzle':False,'bathroom':False,'banksy':False,'romantic':False,'wanted':False,'DrawImage':False,'DrawMissing':{'t1':'','t2':'','t3':'','t4':False},'MakeMeme':False,'mimics': '','messageBOX': {},'listMessage':{},'talkblacklist':{'tos':{}},'unsendMessage':{}, 'replyChat':{}, 'mayhem': []}

khiewuzz1 = {
    "bansky": False,
    "bathroom": False,
    "exdrawing": False,
    "romantic": False,
    "puzzle": False,
    "wanted": False,
    "text1": "",
    "text2": "",
}

itil = {
    "blacklist": {},
}
#=====================================================================
#=====================================================================
settings["myProfile"]["displayName"] = noobcoderProfile.displayName
settings["myProfile"]["statusMessage"] = noobcoderProfile.statusMessage
settings["myProfile"]["pictureStatus"] = noobcoderProfile.pictureStatus
cont = noobcoder.getContact(noobcoderMID)
settings["myProfile"]["videoProfile"] = cont.videoProfile
#coverId = noobcoder.getProfileDetail()["result"]["objectId"]
#settings["myProfile"]["coverId"] = coverId
#=====================================================================
#=====================================================================
noobcoder.kontak = {}
with open("noobcoder/temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("noobcoder/wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu
def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d d %02d h %02d m %02d s' % (days, hours, mins, secs)
def debug():
    get_profile_time_start = time.time()
    get_profile = noobcoder.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = noobcoder.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = noobcoder.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return " SPEED\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
#=====================================================================
def powpow():
    Headers = {
    'User-Agent': "Line/10.15.2",
    'X-Line-Application': "IOSIPAD\t10.15.2\tiPhone X\t13.5.1",
    "x-lal": "ja-US_US",
    }
    return Headers
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
#===================================================================

#def Template(to):
def sendMessageCustom(to, text, icon , name):
    annda = {'MSG_SENDER_ICON': icon,
        'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, text, contentMetadata=annda)
def sendMessageCustomContact(to, icon, name, mid):
    annda = { 'mid': mid,
    'MSG_SENDER_ICON': icon,
    'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, '', annda, 13)

def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest(AppLiff["app"], xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest(AppLiff["app"], xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def B64e(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64encode(url.encode()).decode())

def B64d(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64decode(url.encode()).decode())

#==================== HELP MENU ===============================UPDATED BY ZURAIZ KHAN==========================================
def helpcreator():
    key = kbkb["prefix"]
    key = key.title()
    cmenu = kbkb["cmenubrand"]
    cmenu = cmenu.title()
    emoji = kbkb["emoji"]
    emoji = emoji.title()
    helpMessage = " "+ cmenu +"\n\n" + \
                  "    " + emoji + " About_Buyers " + emoji + "\n" + \
                  "01 " + key + "AddBuyer [mid]\n" + \
                  "02 " + key + "Buyer [Lcon]\n" + \
                  "03 " + key + "Buyer [@]\n" + \
                  "04 " + key + "Buyers\n" + \
                  "05 " + key + "ClearBuyers\n" + \
                  "06 " + key + "DelBuyer [#]\n" + \
                  "07 " + key + "Expel [Lcon]\n" + \
                  "08 " + key + "Expel [@]\n" + \
                  "09 " + key + "Help Buyers\n" + \
                  "10 " + key + "LimitBuyer [#]\n" + \
                  "    " + emoji + " About_Owners " + emoji + "\n" + \
                  "11 " + key + "Help Owners\n" + \
                  "12 " + key + "LimitOwner #\n" + \
                  "    " + emoji + " About_Users " + emoji + "\n" + \
                  "13 " + key + "LimitSb [#]\n" + \
                  "14 " + key + "UpdateAll [pending]\n" + \
                  "    " + emoji + "About_Update " + emoji + "\n" + \
                  "15 " + key + "Upapi [key]\n" + \
                  "16 " + key + "Upbbrand [msg]\n" + \
                  "17 " + key + "Upcbrand [msg]\n" + \
                  "18 " + key + "Upemoji [emoji]\n" + \
                  "19 " + key + "Upobrand [msg]\n" + \
                  "20 " + key + "Uppbrand [msg]\n" + \
                  "    " + emoji + " About_Helper " + emoji + "\n" + \
                  "21 " + key + "AutoAdd [on/off]\n" + \
                  "22 " + key + "ClearBans\n" + \
                  "23 " + key + "ClearCaches\n" + \
                  "24 " + key + "ClearChats\n" + \
                  "25 " + key + "LeaveAll\n" + \
                  "26 " + key + "LogMode [on]\n" + \
                  "27 " + key + "FlexRoom [on]\n" + \
                  "    " + emoji + " About_Nuke " + emoji + "\n" + \
                  "28 " + key + "Bypass [#]\n" + \
                  "29 " + key + "CancelAll\n" + \
                  "30 " + key + "Nukeall"
    return helpMessage

def helpseller():
    key = kbkb["prefix"]
    key = key.title()
    cmenu = kbkb["cmenubrand"]
    cmenu = cmenu.title()
    emoji = kbkb["emoji"]
    emoji = emoji.title()
    helpMessage = " "+ cmenu +"\n\n" + \
                  "    " + emoji + " About_Buyers " + emoji + "\n" + \
                  "01 " + key + "AddBuyer [mid]\n" + \
                  "02 " + key + "Buyer [Lcon]\n" + \
                  "03 " + key + "Buyer [@]\n" + \
                  "04 " + key + "Buyers\n" + \
                  "05 " + key + "ClearBuyers\n" + \
                  "06 " + key + "DelBuyer [#]\n" + \
                  "07 " + key + "Expel [Lcon]\n" + \
                  "08 " + key + "Expel [@]\n" + \
                  "09 " + key + "Help Buyers\n" + \
                  "10 " + key + "LimitBuyer [#]\n" + \
                  "    " + emoji + " About_Owners " + emoji + "\n" + \
                  "11 " + key + "Help Owners\n" + \
                  "12 " + key + "LimitOwner #\n" + \
                  "    " + emoji + " About_Users " + emoji + "\n" + \
                  "13 " + key + "LimitSb [#]\n" + \
                  "14 " + key + "UpdateAll [pending]\n" + \
                  "    " + emoji + "About_Update " + emoji + "\n" + \
                  "15 " + key + "Upapi [key]\n" + \
                  "16 " + key + "Upbbrand [msg]\n" + \
                  "17 " + key + "Upcbrand [msg]\n" + \
                  "18 " + key + "Upemoji [emoji]\n" + \
                  "19 " + key + "Upobrand [msg]\n" + \
                  "20 " + key + "Uppbrand [msg]\n" + \
                  "    " + emoji + " About_Helper " + emoji + "\n" + \
                  "21 " + key + "AutoAdd [on/off]\n" + \
                  "22 " + key + "ClearBans\n" + \
                  "23 " + key + "ClearCaches\n" + \
                  "24 " + key + "ClearChats\n" + \
                  "25 " + key + "LeaveAll\n" + \
                  "26 " + key + "LogMode [on]\n" + \
                  "27 " + key + "FlexRoom [on]\n" + \
                  "    " + emoji + " About_Nuke " + emoji + "\n" + \
                  "28 " + key + "Bypass [#]\n" + \
                  "29 " + key + "CancelAll\n" + \
                  "30 " + key + "Nukeall"
    return helpMessage
    
def helppublic():
    key = kbkb["prefix"]
    key = key.title()
    pmenu = kbkb["pmenubrand"]
    pmenu = pmenu.title()
    emoji = kbkb["emoji"]
    emoji = emoji.title()
    helpMessage = " "+ pmenu +"\n\n" + \
                  " " + emoji + " User-Commands " + emoji + "\n\n" + \
                  "   01 > Login Sb\n" + \
                  "   02 > Logout Sb\n\n" + \
                  "   03 > Login mahnoor\n\n" + \
                  " " + emoji + " Team-Commands " + emoji + "\n\n" + \
                  "   03 > [prefix]help (for Owners)\n" + \
                  "   04 > [prefix]help (for Buyers)\n" + \
                  "   05 > [prefix]menu (for Creators)\n\n" + \
                  " " + emoji + " Public-Commands " + emoji + "\n\n" + \
                  "   06 > BuyerCons\n" + \
                  "   07 > CreatorCons\n" + \
                  "   08 > OwnerCons\n" + \
                  "   09 > ConMid [mid]\n" + \
                  "   10 > Creator\n" + \
                  "   11 > Filter\n" + \
                  "   12 > Liff\n" + \
                  "   13 > Mid [Lcon]\n" + \
                  "   14 > Mycon\n" + \
                  "   15 > Mymid\n" + \
                  "   16 > Ping\n" + \
                  "   17 > Prefix/Rname\n" + \
                  "   18 > Price\n" + \
                  "   19 > Tagall\n" + \
                  "   20 > Reader [on/off]\n" + \
                  "   21 > Rn/Rf\n" + \
                  "   22 > S1/S1f/Sf\n" + \
                  "   23 > S2/S2f/Sf\n" + \
                  "   24 > Bio [@]\n" + \
                  "   25 > Contact [@]\n" + \
                  "   26 > Cover [@]\n" + \
                  "   27 > Getmid [@]\n" + \
                  "   28 > Plink [@]\n" + \
                  "   29 > Profile [@]\n" + \
                  "   30 > Name [@]\n\n" + \
                  "Creator:  ZURAIZ~POWER\n" + \
                  "Version: V_3.75.0"
    return helpMessage

def helpbuyer():
    key = kbkb["prefix"]
    key = key.title()
    bmenu = kbkb["bmenubrand"]
    bmenu = bmenu.title()
    emoji = kbkb["emoji"]
    emoji = emoji.title()
    helpMessage = " "+ bmenu +"\n\n" + \
                  "    " + emoji + " About_Owners " + emoji + "\n" + \
                  "01 " + key + "AddOwner [mid]\n" + \
                  "02 " + key + "ClearOwners\n" + \
                  "03 " + key + "DelOwner [#]\n" + \
                  "04 " + key + "Expel [Lcon]\n" + \
                  "05 " + key + "Expel [@]\n" + \
                  "06 " + key + "Owners\n" + \
                  "07 " + key + "Owner [Lcon]\n" + \
                  "08 " + key + "Owner [@]\n" + \
                  "    " + emoji + " About_Users " + emoji + "\n" + \
                  "09 " + key + "AddMeSb [name]\n" + \
                  "10 " + key + "AddMidSb [name] [mid]\n" + \
                  "11 " + key + "AddSb [name] [@]\n" + \
                  "12 " + key + "DeleteSb [#]\n" + \
                  "13 " + key + "ListLogins\n" + \
                  "14 " + key + "ListSb\n" + \
                  "    " + emoji + " About_Changing " + emoji + "\n" + \
                  "15 " + key + "UpBio [msg]\n" + \
                  "16 " + key + "UpBrand [msg]\n" + \
                  "17 " + key + "UpCover\n" + \
                  "18 " + key + "UpImage\n" + \
                  "19 " + key + "UpName [name]\n" + \
                  "20 " + key + "UpPrefix [key]\n" + \
                  "    " + emoji + " About_Groups " + emoji + "\n" + \
                  "21 " + key + "AutoJoin Set [#]\n" + \
                  "22 " + key + "Accept [#]\n" + \
                  "23 " + key + "AddgKick\n" + \
                  "24 " + key + "CloseQr [#]\n" + \
                  "25 " + key + "MemCon [#]\n" + \
                  "26 " + key + "MentionAll [#]\n" + \
                  "27 " + key + "PenCon [#]\n" + \
                  "28 " + key + "Decline [#]\n" + \
                  "29 " + key + "GetLink [#]\n" + \
                  "30 " + key + "Ginfo [#]\n" + \
                  "31 " + key + "Gkick [#]\n" + \
                  "32 " + key + "GLeave [#]\n" + \
                  "33 " + key + "Groups\n" + \
                  "34 " + key + "GroupCast [msg]\n" + \
                  "35 " + key + "Invited\n" + \
                  "36 " + key + "InviteTo [#]\n" + \
                  "37 " + key + "MemList [#]\n" + \
                  "38 " + key + "PenList [#]\n" + \
                  "    " + emoji + " About_Set_Msgs " + emoji + "\n" + \
                  "39 " + key + "SetAdd [msg]\n" + \
                  "40 " + key + "SetBye [msg]\n" + \
                  "41 " + key + "SetLeave [msg]\n" + \
                  "42 " + key + "SetReader [msg]\n" + \
                  "43 " + key + "SetS1 [msg]\n" + \
                  "44 " + key + "SetS2 [msg]\n" + \
                  "45 " + key + "SetWelcome [msg]\n" + \
                  "    " + emoji + " About_On/Off " + emoji + "\n" + \
                  "46 " + key + "AutoJoin [on/off]\n" + \
                  "47 " + key + "AutoRead [on/off]\n" + \
                  "48 " + key + "LeaveMsg [on/off]\n" + \
                  "49 " + key + "LeaveChat [on/off]\n" + \
                  "50 " + key + "Print [on/off]\n" + \
                  "51 " + key + "Public [on/off]\n" + \
                  "52 " + key + "WelcomeMsg [on/off]\n" + \
                  "    " + emoji + " About_Flex " + emoji + "\n" + \
                  "53 " + key + "AllowLiff\n" + \
                  "54 " + key + "Change App1\n" + \
                  "55 " + key + "Change App2\n" + \
                  "56 " + key + "Change App3\n" + \
                  "57 " + key + "Flex [on/off]\n" + \
                  "    " + emoji + " About_Banning " + emoji + "\n" + \
                  "58 " + key + "Ban [Lcon]\n" + \
                  "59 " + key + "Ban [@]\n" + \
                  "60 " + key + "Listbans\n" + \
                  "61 " + key + "Unban [Lcon]\n" + \
                  "62 " + key + "Unban [@]\n" + \
                  "    " + emoji + " About_Contacts " + emoji + "\n" + \
                  "63 " + key + "Contact Lcancel\n" + \
                  "64 " + key + "Contact Linvite\n" + \
                  "65 " + key + "Contact Ljoin\n" + \
                  "66 " + key + "Contact Lkick\n" + \
                  "67 " + key + "GetCon [Mid]\n" + \
                  "    " + emoji + " About_Inv/Kick/Can " + emoji + "\n" + \
                  "68 " + key + "Invite Lcon\n" + \
                  "69 " + key + "Invite Lkick/Lcancel/Lleave\n" + \
                  "70 " + key + "Invite [@]\n" + \
                  "71 " + key + "Kick Ljoin/Lcancel/Lleave\n" + \
                  "72 " + key + "Kick [@]\n" + \
                  "73 " + key + "Cancel Linvite/Ljoin/Lleave\n" + \
                  "74 " + key + "Cancel [@]\n" + \
                  "    " + emoji + " About_Features " + emoji + "\n" + \
                  "75 " + key + "Abort\n" + \
                  "76 " + key + "About\n" + \
                  "77 " + key + "Bye\n" + \
                  "78 " + key + "LastSeen [@]\n" + \
                  "89 " + key + "Locate [@]\n" + \
                  "80 " + key + "MidLastSeen [mid]\n" + \
                  "81 " + key + "Reboot\n" + \
                  "82 " + key + "Runtime\n" + \
                  "83 " + key + "Say\n" + \
                  "84 " + key + "Screens\n" + \
                  "85 " + key + "Speed\n" + \
                  "86 " + key + "Stats\n" + \
                  "87 " + key + "Unsend [#]\n" + \
                  "    " + emoji + " About_Friends " + emoji + "\n" + \
                  "88 " + key + "AddFriend [@]\n" + \
                  "89 " + key + "AddMe\n" + \
                  "90 " + key + "ClearFriends\n" + \
                  "91 " + key + "Friendcast [msg]\n" + \
                  "92 " + key + "FriendList\n" + \
                  "93 " + key + "MidFriend [mid]"
    return helpMessage


def helpowner():
    key = kbkb["prefix"]
    key = key.title()
    omenu = kbkb["omenubrand"]
    omenu = omenu.title()
    emoji = kbkb["emoji"]
    emoji = emoji.title()
    helpMessage = " "+ omenu +"\n\n" + \
                  "    " + emoji + " About_Users " + emoji + "\n" + \
                  "01 " + key + "AddMeSb [name]\n" + \
                  "02 " + key + "AddMidSb [name] [mid]\n" + \
                  "03 " + key + "AddSb [name] [@]\n" + \
                  "04 " + key + "DeleteSb [#]\n" + \
                  "05 " + key + "ListSb\n" + \
                  "    " + emoji + " About_Features " + emoji + "\n" + \
                  "06 " + key + "About\n" + \
                  "07 " + key + "Bye\n" + \
                  "08 " + key + "Friendcast [msg]\n" + \
                  "09 " + key + "GroupCast [msg]\n" + \
                  "10 " + key + "GetCon [mid]\n" + \
                  "11 " + key + "Say\n" + \
                  "12 " + key + "Speed\n" + \
                  "13 " + key + "Stats\n" + \
                  "14 " + key + "Unsend [#]"
    return helpMessage


#============================FLEX ===================================UPDATED BY ZURAIZ KHAN===========================
def loginsb(to):
    data = {
        "type": "flex",
        "altText": "ZURAIZ~POWER",
        "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/QnPRPtP/ezgif-5-b469058280.png",
            "size": "full",
            "aspectRatio": "640:359",
            "aspectMode": "cover",
            "animated": True,
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/QRCodeReader"
            }
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "aryan1232",
                "wrap": True
              }
            ],
            "position": "absolute",
            "offsetTop": "500000px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ZURAIZ~POWER",
                "color": "#Ffffff",
                "size": "5px",
                "style": "italic",
                "decoration": "underline",
                "align": "center",
                "gravity": "center"
              }
            ],
            "position": "absolute",
            "offsetStart": "228px",
            "backgroundColor": "#000000",
            "offsetTop": "10px",
            "offsetEnd": "26px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "aryan1232",
                "color": "#Ffffff",
                "size": "5px",
                "style": "italic",
                "decoration": "underline",
                "gravity": "center",
                "align": "center"
              }
            ],
            "position": "absolute",
            "offsetStart": "228px",
            "backgroundColor": "#000000",
            "offsetTop": "40px",
            "offsetEnd": "26px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TWITTER",
                "color": "#Ffffff",
                "size": "5px",
                "style": "italic",
                "decoration": "underline",
                "gravity": "center",
                "align": "center"
              }
            ],
            "position": "absolute",
            "offsetStart": "228px",
            "backgroundColor": "#000000",
            "offsetTop": "20px",
            "offsetEnd": "26px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "INSTAGRAM",
                "color": "#Ffffff",
                "size": "5px",
                "style": "italic",
                "decoration": "underline",
                "gravity": "center",
                "align": "center"
              }
            ],
            "position": "absolute",
            "offsetStart": "228px",
            "backgroundColor": "#000000",
            "offsetTop": "30px",
            "offsetEnd": "26px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/MBHvhGX/IMG-20220716-WA0023.jpg",
                "aspectRatio": "1:1",
                "aspectMode": "cover",
                "size": "27px",
                "action": {
                  "type": "uri",
                  "uri": "line://nv/QRCodeReader"
                }
              }
            ],
            "position": "absolute",
            "cornerRadius": "100px",
            "offsetTop": "100px",
            "offsetStart": "215px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/KN26Mzr/Picsart-22-07-15-02-57-19-568.jpg",
                "aspectRatio": "8:2",
                "aspectMode": "cover",
                "size": "27px",
                "action": {
                  "type": "uri",
                  "uri": "line://nv/QRCodeReader"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "102px",
            "offsetStart": "140px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "aryan1232",
                "color": "#Ffffff",
                "size": "5px",
                "style": "italic",
                "decoration": "underline",
                "gravity": "bottom",
                "align": "start"
              }
            ],
            "position": "absolute",
            "offsetStart": "240px",
            "backgroundColor": "#000000",
            "offsetTop": "50px",
            "offsetEnd": "2px"
          }
        ],
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "line://nv/QRCodeReader"
        }
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/YN5mfgR/Picsart-22-07-05-22-11-29-614.jpg",
            "aspectRatio": "1:1",
            "aspectMode": "cover",
            "size": "27px",
            "action": {
              "type": "uri",
              "uri": "line://nv/QRCodeReader"
            }
          }
        ],
        "position": "absolute",
        "cornerRadius": "100px",
        "offsetTop": "64.5px",
        "offsetStart": "50px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [],
        "height": "40px",
        "width": "140px",
        "position": "absolute",
        "offsetEnd": "8px",
        "offsetBottom": "5px",
        "action": {
          "type": "uri",
          "uri": "line://nv/QRCodeReader"
        }
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "aryan1232",
            "wrap": True
          }
        ],
        "position": "absolute",
        "offsetTop": "500000px"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "3px",
    "cornerRadius": "15px",
    "borderColor": "#00b1c4"
  },
  "styles": {
    "body": {
      "backgroundColor": "#00b1c4"
    }
  }
}}
    sendTemplate(to, data)

def menu(to, text):
    if kbkb["flex"] == True:
        mkbkb(to, text)
    if kbkb["chat"] == True:
        noobcoder.sendMessage(to, text)

def mkbkb(to, text):
    cover = noobcoder.getProfileCoverURL(noobcoderMID)
    data = {
    "type": "flex",
    "altText": "ZURAIZ~POWER",
    "contents": 
    {
  "type": "bubble",
  "size": "kilo",
  "hero": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": cover,
            "aspectMode": "cover",
            "size": "full",
            "aspectRatio": "5:2"
          },
          {
            "type": "image",
            "url": "https://g.top4top.io/p_238962e1f0.png",
            "aspectMode": "cover",
            "size": "full",
            "aspectRatio": "5:2",
            "position": "absolute",
            "animated": True
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [],
        "width": "260px",
        "height": "104px",
        "position": "absolute",
        "background": {
          "type": "linearGradient",
          "angle": "0deg",
          "startColor": "#10000Cac",
          "endColor": "#10000Cac"
        }
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "{}".format(setbot["brandname"] ),
            "size": "sm",
            "color": "#ffffff",
            "align": "center",
            "wrap": True
          }
        ],
        "position": "absolute",
        "width": "190px",
        "height": "30px",
        "cornerRadius": "30px",
        "offsetStart": "65px",
        "background": {
          "type": "linearGradient",
          "angle": "0deg",
          "startColor": "#10000Cac",
          "endColor": "#10000Cac",
          "centerColor": "#10000Cac"
        },
        "paddingAll": "7px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
            "size": "full",
            "aspectMode": "cover"
          }
        ],
        "position": "absolute",
        "width": "60px",
        "height": "60px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "14px",
        "offsetStart": "3px",
        "offsetTop": "5px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": cover,
            "position": "absolute",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:7",
            "offsetTop": "0px"
          },
          {
            "type": "image",
            "url": cover,
            "position": "absolute",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:7",
            "offsetTop": "400px"
          },
          {
            "type": "image",
            "url": cover,
            "position": "absolute",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:7",
            "offsetTop": "800px"
          },
          {
            "type": "image",
            "url": cover,
            "position": "absolute",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:7",
            "offsetTop": "1200px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "wrap": True,
                "color": "#ffffff",
                "align": "start",
                "text": text,
                "size": "xxs",
                "offsetStart": "5px"
              }
            ],
            "background": {
              "type": "linearGradient",
              "angle": "0deg",
              "startColor": "#10000Cac",
              "endColor": "#10000Cac"
            }
          }
        ],
        "background": {
          "type": "linearGradient",
          "angle": "0deg",
          "endColor": "#10000Cac",
          "startColor": "#10000Cac",
          "centerColor": "#10000Cac"
        }
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": cover,
            "aspectMode": "cover",
            "size": "full",
            "position": "absolute",
            "aspectRatio": "9:1"
          },
          {
            "type": "image",
            "url": "https://g.top4top.io/p_238962e1f0.png",
            "aspectMode": "cover",
            "size": "full",
            "position": "absolute",
            "aspectRatio": "9:1",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "wrap": True,
                "color": "#ffffff",
                "align": "center",
                "size": "lg",
                "text": "{}".format(noobcoder.getContact(noobcoderMID).displayName)
              }
            ],
            "background": {
              "type": "linearGradient",
              "angle": "0deg",
              "startColor": "#000000aa",
              "endColor": "#000000aa"
            }
          }
        ]
      }
    ],
    "borderWidth": "1px",
    "borderColor": "#ffffff",
    "cornerRadius": "11px",
    "action": {
      "type": "uri",
      "label": "action",
      "uri": "http://line.me/ti/p/~aryan1232"
    }
  }
}}
    sendTemplate(to, data)

def foro(to, text):
    if kbkb["chat"] == True:
        noobcoder.sendMessage(to, text)
    if kbkb["flex"] == True:
        fkbkb(to, text)

def speed(to, text):
    if flex["flex"] == True:
        spspsp(to, text)
    if flex["chat"] == True:
        noobcoder.sendMessage(to, text)


def spspsp(to, text):
    data = {
    "type": "flex",
    "altText": "ZURAIZ~POWER",
    "contents": 
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": "https://i.ibb.co/SBCTnsM/ezgif-3-a3e99ab7d7.png",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "1:1",
        "gravity": "center",
        "animated": True
      },
      {
        "type": "image",
        "url": "https://i.ibb.co/xhj9MJS/photo-1554050857-c84a8abdb5e2-ixlib-rb-1-2.jpg",
        "position": "absolute",
        "size": "290px",
        "aspectMode": "cover",
        "aspectRatio": "1.9:1.9",
        "gravity": "center",
        "offsetTop": "2px",
        "offsetBottom": "2px",
        "offsetStart": "2px",
        "offsetEnd": "2px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/DfPbqHK/ezgif-3-a62f1e0206.png",
            "size": "5xl",
            "animated": True,
            "offsetStart": "35px",
            "offsetTop": "-60px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ZURAIZ"
              }
            ],
            "offsetTop": "100px",
            "offsetStart": "600px"
          }
        ],
        "position": "absolute",
        "offsetTop": "5px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": text,
            "color": "#ffffff",
            "wrap": True,
            "style": "italic",
            "size": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "aryan1232"
              }
            ],
            "offsetTop": "600px",
            "offsetStart": "60px"
          }
        ],
        "position": "absolute",
        "offsetTop": "100px",
        "offsetStart": "50px",
        "width": "200px",
        "height": "180px"
      }
    ],
    "paddingAll": "0px"
  }
}}
    sendTemplate(to, data)

def fkbkb(to, text):
    data = {
    "type": "flex",
    "altText": "ZURAIZ~POWER",
    "contents": 
    {
  "type": "bubble",
  "size": "kilo",
  "body": {
    "type": "box",
    "action": {
      "type": "uri",
      "label": "action",
      "uri": "http://line.me/ti/p/~aryan1232"
    },
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": "https://i.ibb.co/8XVVsz0/ezgif-4-91a2e0aa23.png",
        "position": "absolute",
        "size": "full",
        "aspectRatio": "1:2",
        "aspectMode": "cover",
        "animated": True,
        "offsetTop": "0px",
        "offsetBottom": "0px",
        "offsetStart": "0px",
        "offsetEnd": "0px"
      },
      {
        "type": "image",
        "url": "https://i.ibb.co/8XVVsz0/ezgif-4-91a2e0aa23.png",
        "position": "absolute",
        "size": "full",
        "aspectRatio": "1:2",
        "aspectMode": "cover",
        "animated": True,
        "offsetTop": "50px",
        "offsetBottom": "0px",
        "offsetStart": "0px"
      },
      {
        "type": "image",
        "url": "https://i.ibb.co/8XVVsz0/ezgif-4-91a2e0aa23.png",
        "position": "absolute",
        "size": "full",
        "aspectRatio": "1:2",
        "aspectMode": "cover",
        "animated": True,
        "offsetTop": "100px",
        "offsetBottom": "0px",
        "offsetStart": "0px"
      },
      {
        "type": "image",
        "url": "https://i.ibb.co/8XVVsz0/ezgif-4-91a2e0aa23.png",
        "position": "absolute",
        "size": "full",
        "aspectRatio": "1:2",
        "aspectMode": "cover",
        "animated": True,
        "offsetTop": "200px",
        "offsetBottom": "0px",
        "offsetStart": "0px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "ZURAIZ",
          }
        ],
        "position": "absolute",
        "offsetBottom": "-500px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "filler"
              }
            ],
            "offsetBottom": "0px",
            "offsetStart": "0px",
            "offsetEnd": "0px",
            "offsetTop": "0px",
            "paddingAll": "19px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/8XVVsz0/ezgif-4-91a2e0aa23.png",
                "size": "full",
                "gravity": "top",
                "aspectRatio": "3:1.3",
                "position": "absolute",
                "aspectMode": "cover",
                "offsetTop": "-5px",
                "animated": True
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [],
                "offsetTop": "0px",
                "offsetBottom": "0px",
                "offsetStart": "0px",
                "offsetEnd": "0px",
                "position": "absolute",
                "background": {
                  "type": "linearGradient",
                  "angle": "0deg",
                  "startColor": "#380B21aa",
                  "endColor": "#000000cc",
                  "centerColor": "#0B0B3Baa"
                }
              }
            ],
            "position": "absolute",
            "offsetTop": "0px",
            "offsetBottom": "0px",
            "offsetStart": "0px",
            "offsetEnd": "0px",
            "backgroundColor": "#0B0B3Baa"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png",
                "size": "xxs",
                "offsetStart": "-15px"
              },
              {
                "type": "text",
                "size": "sm",
                "color": "#FFFFFF",
                "wrap": True,
                "gravity": "center",
                "align": "center",
                "contents": [],
                "text": text
              },
              {
                "type": "icon",
                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png",
                "size": "xxs",
                "offsetEnd": "-15px"
              }
            ],
            "paddingAll": "1px",
            "offsetBottom": "2px"
          }
        ],
        "borderWidth": "light",
        "cornerRadius": "9px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/8XVVsz0/ezgif-4-91a2e0aa23.png",
                "size": "full",
                "aspectMode": "cover",
                "animated": True
              }
            ],
            "position": "absolute",
            "height": "1px",
            "offsetTop": "22px",
            "offsetStart": "20px",
            "offsetEnd": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact(noobcoderMID).displayName),
                "size": "sm",
                "color": "#FFFFFF",
                "align": "center"
              }
            ],
            "offsetStart": "40px",
            "offsetEnd": "40px",
            "position": "absolute",
            "offsetTop": "3px"
          }
        ],
        "position": "absolute",
        "offsetTop": "0px",
        "offsetBottom": "0px",
        "offsetStart": "0px",
        "offsetEnd": "0px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/8XVVsz0/ezgif-4-91a2e0aa23.png",
            "size": "full",
            "aspectMode": "cover",
            "animated": True
          }
        ],
        "position": "absolute",
        "width": "28px",
        "height": "28px",
        "offsetTop": "8px",
        "cornerRadius": "100px",
        "offsetStart": "8px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
            "size": "full",
            "aspectMode": "cover"
          }
        ],
        "position": "absolute",
        "width": "26px",
        "height": "26px",
        "cornerRadius": "100px",
        "offsetTop": "9px",
        "offsetStart": "9px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/8XVVsz0/ezgif-4-91a2e0aa23.png",
            "size": "full",
            "aspectMode": "cover",
            "animated": True
          }
        ],
        "position": "absolute",
        "width": "28px",
        "height": "28px",
        "offsetTop": "8px",
        "offsetEnd": "8px",
        "cornerRadius": "100px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
            "size": "full",
            "aspectMode": "cover"
          }
        ],
        "position": "absolute",
        "width": "26px",
        "height": "26px",
        "cornerRadius": "100px",
        "offsetTop": "9px",
        "offsetEnd": "9px"
      }
    ],
    "backgroundColor": "#0000ff",
    "paddingAll": "2px"
  }
}}
    sendTemplate(to, data)
    

def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact("ub945f05f07d5593adc00ab9bbc9db0e1").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact("ub945f05f07d5593adc00ab9bbc9db0e1").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)


def countLexe(to,lexe,x):
        num = 0
        ngen = []
        tot = 0
        if "ljoin" == lexe:
            tot += len(lastall["ljoin"][to])
            tot -= int(x)
            for a in lastall["ljoin"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "lkick" == lexe:
            tot += len(lastall["lkick"][to])
            tot -= int(x)
            for a in lastall["lkick"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "lcancel" == lexe:
            tot += len(lastall["lcancel"][to])
            tot -= int(x)
            for a in lastall["lcancel"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "lleave" == lexe:
            tot += len(lastall["lleave"][to])
            tot -= int(x)
            for a in lastall["lleave"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "linvite" == lexe:
            tot += len(lastall["linvite"][to])
            tot -= int(x)
            for a in lastall["linvite"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
        if "lcon" == lexe:
            tot += len(lastall["lcon"][to])
            tot -= int(x)
            for a in lastall["lcon"][to]:
                num +=1
                if num == tot:
                    ngen.append(a)
                    num -=1
            return ngen
            
def mentions2(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@ZURAIZ"
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@oviGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def allowLiff():
    data = {'on': ['P', 'CM'], 'off': []}
    headers = {
        'X-Line-Access': noobcoder.authToken,
        'X-Line-Application': noobcoder.server.APP_NAME,
        'X-Line-ChannelId': '1602687308',
        'Content-Type': 'application/json'
    }
    r = noobcoder.server.postContent('https://access.line.me/dialog/api/permissions', headers=headers, data=json.dumps(data))

def sendbroadcast(to, text):
    noobcoder.sendMessage(squad, text)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoderMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        noobcoder.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("noobcoderWasHere.mp4")
#=====================================================================
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)
        
def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()
	
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        noobcoder.sendMessage(to, textx, {'MSG_SENDER_NAME': client.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def logError(text):
    noobcoder.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("noobcoder/errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
#=====================================================================
#=====================================================================
def command(text):
    pesan = text.lower()
    if kbkb["setKey"] == True:
        if pesan.startswith(kbkb["keyCommand"]):
            cmd = pesan.replace(kbkb["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
#=====================================================================
def removeCmd(cmd, text):
	key = kbkb["keyCommand"]
	if kbkb["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def backupData():
    try:
        backup = settings
        f = codecs.open('noobcoder/temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('noobcoder/wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = premium
        f = codecs.open('noobcoder/user.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = log
        f = codecs.open('database.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = seens
        f = codecs.open('lastseen.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False

def mentionMembers2(gid, mids=[]):
    if noobcoderMID in mids: mids.remove(noobcoderMID)
    parsed_len = len(mids)//20+1
    G = noobcoder.getGroup(gid)
    result = ' MENTIONALL \n\n'
    result += '  Memberlist\n'
    mention = '@ZURAIZ\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '\t %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '  Group: ' + G.name
                result += '\n\n👑 MENTIONALL 👑'
        if result:
            if result.endswith('\n'): result = result[:-1]
            noobcoder.sendMessage(gid, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''

def anulurk(to, wait):
    moneys = {}
    for a in wait["setTime"][to].items():
        moneys[a[1]] = [a[0]] if a[1] is not None else idnya
    sort = sorted(moneys)
    sort = sort[0:]
    k = len(sort)//100
    for a in range(k+1):
        if a == 0:no= a;msgas = 'Lurkers'
        else:no = a*100;msgas = 'Lurkers'
        h = []
        for i in sort[a*100 : (a+1)*100]:
            h.append(moneys[i][0])
            no+=1
            a = '{}'.format(humanize.naturaltime(datetime.fromtimestamp(i/1000)))
            if no == len(sort):msgas+='\n{}. @!\n    {}'.format(no,a)
            else:msgas+='\n{}. @!\n    {}'.format(no,a)
        mentions(to, msgas, h)
#=====================================================================
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
#=====================================================================
async def noobcoderBot(op):
    try:
        if settings["restartPoint"] != None:
            noobcoder.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return
        if op.type == 5:
            if kbkb["add"] == True:
                noobcoder.findAndAddContactsByMid(op.param1)
                noobcoder.sendMessage(op.param1, "Assalam-O-Alaikum, " + noobcoder.getContact(op.param1).displayName + "\n\n{}".format(kbkb["addmsg"]))
                for i in creator:
                    ma = noobcoder.getContact(i)
                    noobcoder.sendMessage(op.param1, None, contentMetadata={'mid': i}, contentType=13)
                return
            

        if op.type in [22,24]:
            noobcoder.leaveRoom(op.param1)

#=====================================================================
        if op.type == 13 or op.type == 124:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if settings["autoJoin"] == True:
                    noobcoder.acceptGroupInvitation(op.param1)
                    noobcoder.sendMessage(op.param1,"Assalam-O-Alaikum!  " + noobcoder.getContact(op.param2).displayName + "\n\nThank You For Inviting Me To The Group  Type 'Help' to see available commands and Contact Buyers for the Services.")
                    for i in creator:
                        ma = noobcoder.getContact(i)
                        noobcoder.sendMessage(op.param1, None, contentMetadata={'mid': i}, contentType=13)

        if op.type == 17 or op.type == 60:
            if kbkb["welcome"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                noobcoder.sendMessage(op.param1, "Hey, "+str(noobcoder.getContact(op.param2).displayName)+"\n" +str(welcome["welcomee"]))
                return
            if op.param2 not in lastall["ljoin"]:
                if op.param1 not in lastall["ljoin"]:
                    lastall["ljoin"][op.param1] = {op.param2:True}
                else:
                    lastall["ljoin"][op.param1][op.param2] = True

        if op.type == 13 or op.type == 124:
            if op.param3 not in lastall["linvite"]:
                if op.param1 not in lastall["linvite"]:
                    lastall["linvite"][op.param1] = {op.param3:True}
                else:
                    lastall["linvite"][op.param1][op.param3] = True

        if op.type == 15 or op.type == 61:
            if kbkb["leave"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                noobcoder.sendMessage(op.param1, "Hey, "+str(noobcoder.getContact(op.param2).displayName)+"\n" +str(kbkb["leavemsg"]))
                return
            if op.param2 not in lastall["lleave"]:
                if op.param1 not in lastall["lleave"]:
                    lastall["lleave"][op.param1] = {op.param2:True}
                else:
                    lastall["lleave"][op.param1][op.param2] = True

        if op.type == 19 or op.type == 133:
            if op.param3 not in lastall["lkick"]:
                if op.param1 not in lastall["lkick"]:
                    lastall["lkick"][op.param1] = {op.param3:True}
                else:
                    lastall["lkick"][op.param1][op.param3] = True

        if op.type == 32 or op.type == 126:
            if op.param3 not in lastall["lcancel"]:
                if op.param1 not in lastall["lcancel"]:
                    lastall["lcancel"][op.param1] = {op.param3:True}
                else:
                    lastall["lcancel"][op.param1][op.param3] = True

        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            comma = command(text)
            if msg.toType == 0 and sender != noobcoderMID: to = sender
            else: to = receiver

        if op.type in (25,26):
          if msg._from in kbkb["print"]:
            try:
                print(msg.contentMetadata)
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != noobcoder.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                        if msg.contentMetadata in ({},{'EMTVER': '4'}):
                            pass
                        else:
                            noobcoder.sendMessage(flexroom, str(msg.contentMetadata))
            except Exception as error:
                logError(error)

        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message               
            text = msg.text
            msg_id = msg.id
            receiver = msg.to             
            sender = msg._from
            #s = noobcoder.getProfile().mid
            setKey = kbkb["keyCommand"].title()
            if kbkb["setKey"] == False:
               setKey = ''
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:                    	
                    if sender != noobcoder.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if sender != "ud142630615f8da4dcb9c7fbaed5c4c97":
                	        peler["receivercount"] += 1
                        if sender == "ud142630615f8da4dcb9c7fbaed5c4c97":
                	        peler["sendcount"] += 1

        if op.type == 55:
            try:
                Name = noobcoder.getContact(op.param2).mid
                group = noobcoder.getGroup(op.param1).name
                tz = pytz.timezone("Asia/karachi")
                timeNow = datetime.now(tz=tz)
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                bulan = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                hr = timeNow.strftime("%A")
                bln = timeNow.strftime("%m")
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bln == str(k): bln = bulan[k-1]
                readTime = timeNow.strftime('%H.%M')
                readTime2 = hr
                readTime3 = timeNow.strftime('%d') + "-" + bln + "-" + timeNow.strftime('%Y')
                seens["username"][Name] = "was lastseen\nin group ' " + group + " '\nat time " + readTime + " Pak\non " + readTime2 + ", " + readTime3
                seens['find'][op.param2] = True
            except:
                pass


#=====================================================================
#==========================================
#==========================================
        if op.type in [22,24]:
            if kbkb["leavechat"] == True:
                foro(op.param1,"Auto Leave Multi Chat")
                noobcoder.leaveRoom(op.param1)
        if op.type == 55:
            #print ("[ 55 ] NOTIFIED READ MESSAGE")
            if op.param1 in tailah["siderTemp"] and op.param2 not in tailah["siderTemp"][op.param1]:
                tailah["siderTemp"][op.param1].append(op.param2)
                contact = noobcoder.getContact(op.param2)
                pesan = tailah["siderPesan"]
                noobcoder.sendMessage(op.param1, "{}, {}".format(str(pesan),contact.displayName))

        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass

        if op.type == 55:
            #print ("[ 55 ] NOTIFIED READ MESSAGE")
            if op.param1 in tailah1["siderTemp"] and op.param2 not in tailah1["siderTemp"][op.param1]:
                tailah1["siderTemp"][op.param1].append(op.param2)
                contact = noobcoder.getContact(op.param2)
                pesan = tailah1["siderPesan"]
                data = {
    "type": "flex",
    "altText": pesan,
    "contents": 
    {
  "type": "bubble",
  "size": "kilo",
  "hero": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": cover,
            "aspectMode": "cover",
            "size": "full",
            "aspectRatio": "5:1"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [],
        "width": "260px",
        "height": "52px",
        "position": "absolute",
        "background": {
          "type": "linearGradient",
          "angle": "0deg",
          "startColor": "#10000Cac",
          "endColor": "#10000Cac"
        }
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "{}".format(contact.displayName),
            "size": "xxs",
            "color": "#ffffff",
            "align": "start",
            "wrap": True
          }
        ],
        "position": "absolute",
        "width": "140px",
        "height": "20px",
        "offsetTop": "16px",
        "cornerRadius": "30px",
        "offsetStart": "50px",
        "background": {
          "type": "linearGradient",
          "angle": "0deg",
          "startColor": "#10000Cac",
          "endColor": "#10000Cac",
          "centerColor": "#10000Cac"
        },
        "paddingAll": "2px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
            "size": "full",
            "aspectMode": "cover"
          }
        ],
        "position": "absolute",
        "width": "40px",
        "height": "40px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "14px",
        "offsetStart": "3px",
        "offsetTop": "5px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": cover,
            "position": "absolute",
            "size": "full",
            "aspectMode": "cover"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "wrap": True,
                "color": "#ffffff",
                "align": "center",
                "text": "{}".format(pesan),
                "size": "xxs"
              }
            ],
            "background": {
              "type": "linearGradient",
              "angle": "0deg",
              "startColor": "#10000Cac",
              "endColor": "#10000Cac"
            }
          }
        ],
        "background": {
          "type": "linearGradient",
          "angle": "0deg",
          "endColor": "#10000Cac",
          "startColor": "#10000Cac",
          "centerColor": "#10000Cac"
        }
      }
    ],
    "borderWidth": "1px",
    "borderColor": "#ffffff",
    "cornerRadius": "11px",
    "action": {
      "type": "uri",
      "label": "action",
      "uri": "http://line.me/ti/p/~aryan1232"
    }
  }
}}
                sendTemplate(op.param1, data)

        if op.type == 55:
            #print ("[ 55 ] NOTIFIED READ MESSAGE")
            if op.param1 in tailah2["siderTemp"] and op.param2 not in tailah2["siderTemp"][op.param1]:
                tailah2["siderTemp"][op.param1].append(op.param2)
                contact = noobcoder.getContact(op.param2)
                pesan = tailah2["siderPesan"]
                data = {
    "type": "flex",
    "altText": pesan,
    "contents": 
    {
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "4:6"
      },
      {
        "type": "image",
        "url": "https://g.top4top.io/p_238962e1f0.png",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "4:6",
        "position": "absolute",
        "animated": True
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [],
        "width": "200px",
        "background": {
          "type": "linearGradient",
          "angle": "0deg",
          "startColor": "#10000Cac",
          "endColor": "#10000Cac"
        },
        "height": "240px",
        "position": "absolute"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
            "size": "full",
            "aspectMode": "cover"
          }
        ],
        "position": "absolute",
        "width": "50px",
        "offsetTop": "10px",
        "offsetStart": "5px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "14px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "{}".format(contact.displayName),
            "color": "#ffffff",
            "size": "xxs",
            "wrap": True,
            "align": "start",
            "offsetStart": "2px"
          },
          {
            "type": "separator"
          },
          {
            "type": "text",
            "text": "{}".format(pesan),
            "color": "#ffffff",
            "size": "xxs",
            "wrap": True,
            "align": "end",
            "offsetEnd": "1px"
          }
        ],
        "position": "absolute",
        "offsetTop": "184px",
        "width": "160px",
        "height": "50px"
      }
    ]
  }
}}
                sendTemplate(op.param1, data)
                


        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = kbkb["keyCommand"].title()
            if kbkb["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 13:
                    if to not in lastall["lcon"]:
                        lastall["lcon"][to] = {msg.contentMetadata["mid"]:True}
                    else:
                        lastall["lcon"][to][msg.contentMetadata["mid"]] = True
                        return
                    if kbkb["kicker"] == True:
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            kick["kicker"][msg.contentMetadata["mid"]] = True
                            noobcoder.sendMessage(to, "Successful Added Gkick.")
                            kbkb["kicker"] = False

                if msg.contentType == 14:
                    if hoho["savefile"] == True:
                        try:
                             namafile = hoho["namafile"]
                             noobcoder.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             noobcoder.sendMessage(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	noobcoder.sendMessage(to, str(e))
                if msg.contentType == 1:
                    if kbkb["changeCover"] == True:
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/cover.bin")
                            kbkb['changeProfileCover'] = path
                            kbkb["changeCover"] = False
                            cover = str(kbkb["changeProfileCover"])
                            noobcoder.updateProfileCover(cover)
                            noobcoder.sendMessage(to, "Cover Image Updated.")
                    if kbkb["changePicture"] == True:
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                            kbkb["changePicture"] = False
                            noobcoder.updateProfilePicture(path)
                            foro(to,"Profile Image Updated.")
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if kbkb["read"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if kbkb["read"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
#==========================================


                    if text.lower() == ".":           
                        if kbkb["public"] == True:
                            noobcoder.sendMessage(to,"{}".format(setbot["brandname"]))

#==========================================LOGIN QR COAD UPDATED BY ZURAIZ KHAN ============================================
                    elif text.lower() == "login sb" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                user = premium["myService"][msg._from]
                                try:
                                    def kentod():
                                        qr = shahzi.LineGetQr("DESKTOPMAC\t7.5.0\tmacOS\t11.6")
                                        noobcoder.sendMessage(to, "Link QR: "+qr["result"]["qrlink"])
                                        noobcoder.sendImageWithURL(to, qr["result"]["qrcode"])
                                        pincode = shahzi.lineGetQrPincode(qr["result"]["session"])
                                        noobcoder.sendMessage(to, "Your Pincode: "+pincode["result"])
                                        auth = shahzi.lineGetQrAuth(qr["result"]["session"])
                                        authToken,cert = auth["result"]["accessToken"],auth["result"]["certificate"]
                                        zzz = authToken
                                        yyy = cert
                                        if msg._from not in premium['listLogin']:
                                            premium['listLogin'][msg._from] =  '%s' % user
                                            isi = "{}".format(zzz)
                                            os.system('cp -r login {}'.format(user))
                                            os.system('cd {} && echo -n "{}" > token.txt'.format(user, isi))
                                            os.system('screen -dmS {}'.format(user))
                                            os.system('screen -r {} -X stuff "cd {} && python3 staff2.py \n"'.format(user, user))
                                            noobcoder.sendMessage(to, "Your Selfbot logged in successfully!")
                                    thread = threading.Thread(target=kentod)
                                    thread.daemon = True
                                    thread.start()
                                except Exception as e:
                                    print(e)
                                   
                    elif text.lower() == "login mahnoor" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                user = premium["myService"][msg._from]
                                try:
                                    def kentod():
                                        qr = shahzi.LineGetQr("DESKTOPMAC\t7.5.0\tmacOS\t11.6")
                                        noobcoder.sendMessage(to, "Link QR: "+qr["result"]["qrlink"])
                                        noobcoder.sendImageWithURL(to, qr["result"]["qrcode"])
                                        pincode = shahzi.lineGetQrPincode(qr["result"]["session"])
                                        noobcoder.sendMessage(to, "Your Pincode: "+pincode["result"])
                                        auth = shahzi.lineGetQrAuth(qr["result"]["session"])
                                        authToken,cert = auth["result"]["accessToken"],auth["result"]["certificate"]
                                        zzz = authToken
                                        yyy = cert
                                        if msg._from not in premium['listLogin']:
                                            premium['listLogin'][msg._from] =  '%s' % user
                                            isi = "{}".format(zzz)
                                            os.system('cp -r login2 {}'.format(user))
                                            os.system('cd {} && echo -n "{}" > token.txt'.format(user, isi))
                                            os.system('screen -dmS {}'.format(user))
                                            os.system('screen -r {} -X stuff "cd {} && python3 staff2.py \n"'.format(user, user))
                                            noobcoder.sendMessage(to, "Your Selfbot logged in successfully! contact for creator for more info thanks!")
                                    thread = threading.Thread(target=kentod)
                                    thread.daemon = True
                                    thread.start()
                                except Exception as e:
                                    print(e)
                                   


#========================================== LOGIN QR UPDATED BY ZURAIZ KHAN ==============================================================
                    elif text.lower() == "login sb" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            noobcoder.sendMention(to, ' Login Notice \n Status : Incorrect\n User :  @!\nBefore  < logout sb > You should write',' ', [msg._from])

                    elif text.lower() == "logout sb" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"] :
                            del premium['listLogin'][msg._from]
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('rm -rf {}'.format(str(user)))
                            time.sleep(0.5)
                            noobcoder.sendMention(to, 'Your Selfbot Has Been Logged Out\nUser: @!',' ', [msg._from])    

                    elif text.lower() == "logout sb" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            noobcoder.sendMention(to, 'Exit \nStatus : Incorrect\nUser : @!\n You Should Login First Before Logout',' ', [msg._from])

########################################################
                    elif cmd.startswith("addsb "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            if len(list(premium["myService"])) < kbkb["limitsb"]:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    if key1 in banuser:
                                        noobcoder.sendMessage(to, "User Banned By Creator")
                                    else:
                                        if key1 not in premium['myService']:
                                            nama = str(text.split(' ')[1])
                                            premium['myService'][key1] =  '%s' % nama
                                            foro(to,"Added To SbList:\n{}".format(noobcoder.getContact(key1).displayName))
                                            noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded To Selfbot User:\n" +str(noobcoder.getContact(key1).displayName))
                                        else:
                                            foro(to,"Already In SbList:\n{}".format(noobcoder.getContact(key1).displayName))
                            else:
                                noobcoder.sendMessage(to,"SbList is Full")

                    elif cmd.startswith("addmidsb"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            if len(list(premium["myService"])) < kbkb["limitsb"]:
                                anu = msg.text.split(" ")
                                anu2 = msg.text.replace(anu[0] + " ","")
                                anu3 = anu2.split(" ")
                                nama = str(anu3[0])
                                mid = str(anu3[1])
                                if mid in banuser:
                                    noobcoder.sendMessage(to, "User Banned By Creator")
                                else:
                                    if mid in premium['myService']:
                                        foro(to, "Already In SbList:\n" +str(noobcoder.getContact(mid).displayName))
                                    if mid not in premium['myService']:
                                        noobcoder.findAndAddContactsByMid(mid)
                                        premium['myService'][mid] =  '%s' % nama
                                        foro(to, "Added to SbList:\n" +str(noobcoder.getContact(mid).displayName))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded To Selfbot User:\n" +str(noobcoder.getContact(mid).displayName))
                            else:
                                noobcoder.sendMessage(to,"SbList is Full")

                    elif cmd.startswith("deletesb "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            h = [a for a in premium['myService']]
                            mid = h[int(text.lower().split(' ')[1])-1]
                            user = premium["myService"][mid]
                            if mid in premium['listLogin']:
                                del premium['listLogin'][mid]
                            if mid in premium['myService']:
                                del premium['myService'][mid]
                                os.system("screen -S {} -X kill".format(user))
                                os.system('rm -r {}'.format(user))
                                foro(to, "Removed From SbList:\n" +str(noobcoder.getContact(mid).displayName))
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved From Selfbot User:\n" +str(noobcoder.getContact(mid).displayName))

                    elif cmd == "listsb":
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            h = [a for a in premium['myService']]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:msgas = "🥂 𝐋𝐈𝐒𝐓–𝐒𝐁 🥂\n";no = aa
                                else:msgas = "🥂 𝐋𝐈𝐒𝐓–𝐒𝐁 🥂\n";no = aa * 20
                                for a in h[aa * 20 : (aa + 1) * 20]:
                                    no+=1
                                    if premium['myService'][a] == "":cd = "None."
                                    else:cd = premium['myService'][a]
                                    if no == len(h):msgas+='\n{}. @!\n• File Name: [ {} ]'.format(no,cd)
                                    else:msgas+='\n{}. @!\n• File Name: [ {} ]'.format(no,cd)
                                noobcoder.sendMention(to, msgas,'', h[aa * 20 : (aa+1)*20])

                    elif cmd.startswith("addmesb "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            if len(list(premium["myService"])) < kbkb["limitsb"]:
                                if msg._from in premium["myService"]:
                                    foro(to, "Already In SbList:\n" +str(noobcoder.getContact(sender).displayName))
                                if msg._from not in premium["myService"]:
                                    nama = str(text.split(' ')[1])
                                    premium['myService'][msg._from] =  '%s' % nama
                                    foro(to, "Added To SbList:\n" +str(noobcoder.getContact(sender).displayName))
                                    noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdd To Selfbot User:\n" +str(noobcoder.getContact(sender).displayName))
                            else:
                                noobcoder.sendMessage(to,"SbList is Full")

#========================================RANKS SELLER BUYER OWNER CREATOR ==============================================================
                    elif cmd == "sellers":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            tx = "👑 𝐁𝐔𝐘𝐄𝐑𝐒 👑\n"
                            num = 0
                            for b in seller:
                                num += 1
                                try:tx += "\n{}. {}".format(num,noobcoder.getContact(b).displayName)
                                except:sellers.remove(b)
                            foro(to, tx)

                    elif text.lower() == "Sellercons":
                      if kbkb["public"] == True:
                        for i in Seller:
                            ma = noobcoder.getContact(i)
                            noobcoder.sendMessage(to, None, contentMetadata={'mid': i}, contentType=13)



                    elif cmd.startswith('seller'):
                        if msg._from in creator:
                            if len(list(seller)) < kbkb["limitsellerr"]:
                                proses = text.split(" ")
                                lcon = text.replace(proses[0] + " lcon", "")
                                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                                    if "" == lcon:
                                        lcon = "1"
                                    l = int(lcon)
                                    l -= 1
                                    hasil = countLexe(to,"lcon",l)
                                    numb = 0
                                    for s in hasil:
                                        if s not in seller:
                                            aadmin["sellers"][s] = True
                                            numb += 1
                                            tx = "Promoted As A Seller:{}".format(str(numb))
                                            foro(to, tx)
                                        else:
                                            foro(to, "Already in SellerList")
                            else:
                                noobcoder.sendMessage(to,"SellerList is Full")
                                return
                            if len(list(seller)) < kbkb["limitseller"]:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for cust in targets:
                                    if cust not in seller:
                                        aadmin["sellers"][cust] = True
                                        noobcoder.findAndAddContactsByMid(cust)
                                        foro(to,"Promoted As A Seller:\n{}".format(noobcoder.getContact(cust).displayName))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded A Seller:\n" +str(noobcoder.getContact(cust).displayName))
                                    else:
                                        foro(to, "Already in SellerList!")
                            else:
                                foro(to,"SellerList is Full")

                    elif cmd.startswith('addSeller'):
                        if msg._from in creator:
                            if len(list(Seller)) < kbkb["limitSeller"]:
                                sep = text.split(" ")
                                search = text.replace(sep[0] + " ","")
                                if search in banuser:
                                    noobcoder.sendMessage(to, "User Banned By Creator")
                                else:
                                    if search in Seller:
                                        foro(to, "Already in SellerList:\n" +str(noobcoder.getContact(search).displayName))
                                    if search not in Seller:
                                        noobcoder.findAndAddContactsByMid(search)
                                        aadmin["sellers"][search] = True
                                        foro(to, "Promoted As An Seller:\n" +str(noobcoder.getContact(search).displayName))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded A Seller:\n" +str(noobcoder.getContact(search).displayName))
                            else:
                                noobcoder.sendMessage(to,"SellerList is Full")

                    elif cmd == "creators":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            tx = "👑 𝐁𝐔𝐘𝐄𝐑𝐒 👑\n"
                            num = 0
                            for b in creator:
                                num += 1
                                try:tx += "\n{}. {}".format(num,noobcoder.getContact(b).displayName)
                                except:creator.remove(b)
                            foro(to, tx)

                    elif cmd == "buyers":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            tx = "👑 𝐁𝐔𝐘𝐄𝐑𝐒 👑\n"
                            num = 0
                            for b in buyer:
                                num += 1
                                try:tx += "\n{}. {}".format(num,noobcoder.getContact(b).displayName)
                                except:buyer.remove(b)
                            foro(to, tx)

                    elif text.lower() == "buyercons":
                      if kbkb["public"] == True:
                        for i in buyer:
                            ma = noobcoder.getContact(i)
                            noobcoder.sendMessage(to, None, contentMetadata={'mid': i}, contentType=13)

 

                    elif cmd.startswith('buyer'):
                        if msg._from in creator or msg._from in seller:
                            if len(list(buyer)) < kbkb["limitbuyer"]:
                                proses = text.split(" ")
                                lcon = text.replace(proses[0] + " lcon", "")
                                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                                    if "" == lcon:
                                        lcon = "1"
                                    l = int(lcon)
                                    l -= 1
                                    hasil = countLexe(to,"lcon",l)
                                    numb = 0
                                    for s in hasil:
                                        if s not in buyer:
                                            aadmin["owners"][s] = True
                                            numb += 1
                                            tx = "Promoted As A Buyer:{}".format(str(numb))
                                            foro(to, tx)
                                        else:
                                            foro(to, "Already in BuyerList")
                            else:
                                noobcoder.sendMessage(to,"BuyerList is Full")
                                return
                            if len(list(buyer)) < kbkb["limitbuyer"]:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for cust in targets:
                                    if cust not in buyer:
                                        aadmin["owners"][cust] = True
                                        noobcoder.findAndAddContactsByMid(cust)
                                        foro(to,"Promoted As A Buyer:\n{}".format(noobcoder.getContact(cust).displayName))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded A Buyer:\n" +str(noobcoder.getContact(cust).displayName))
                                    else:
                                        foro(to, "Already in BuyerList!")
                            else:
                                foro(to,"BuyerList is Full")


                    elif cmd.startswith('expel'):
                        proses = text.split(" ")
                        lcon = text.replace(proses[0] + " lcon", "")
                        if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                            if "" == lcon:
                                lcon = "1"
                            l = int(lcon)
                            l -= 1
                            hasil = countLexe(to,"lcon",l)
                            numb = 0
                            for s in hasil:
                                if msg._from in creator or msg._from in seller:
                                    if s in buyer:
                                        del aadmin["owners"][s]
                                        numb += 1
                                        foro(to,"Expelled From BuyerList: {}".format(numb))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved from Buyer:\n" +str(noobcoder.getContact(s).displayName))
                                if msg._from in creator or msg._from in seller or msg._from in buyer:
                                    if s in owner:
                                        del aadmin["admins"][s]
                                        numb += 1
                                        foro(to,"Expelled From OwnerList: {}".format(numb))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved from Owner:\n" +str(noobcoder.getContact(s).displayName))
                                        return
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for cust in targets:
                            if msg._from in creator or msg._from in seller:
                                if cust in buyer:
                                    del aadmin["owners"][cust]
                                    foro(to,"Expelled From BuyerList: \n{}".format(noobcoder.getContact(cust).displayName))
                                    noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved from Buyer:\n" +str(noobcoder.getContact(cust).displayName))
                            if msg._from in creator or msg._from in seller or msg._from in buyer:
                                if cust in owner:
                                    del aadmin["admins"][cust]
                                    foro(to,"Expelled From OwnerList: \n{}".format(noobcoder.getContact(cust).displayName))
                                    noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved from Owner:\n" +str(noobcoder.getContact(cust).displayName))

                    elif cmd == "owners":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            tx = "🥂 𝐎𝐖𝐍𝐄𝐑𝐒 🥂\n"
                            num = 0
                            for b in owner:
                                num += 1
                                try:tx += "\n{}. {}".format(num,noobcoder.getContact(b).displayName)
                                except:owner.remove(b)
                            foro(to, tx)

                    elif cmd == "listbans":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            tx = "🚫 𝐋𝐈𝐒𝐓𝐁𝐀𝐍𝐒 🚫\n"
                            num = 0
                            for b in banuser:
                                num += 1
                                try:tx += "\n{}. {}".format(num,noobcoder.getContact(b).displayName)
                                except:banuser.remove(b)
                            foro(to, tx)

                    elif text.lower() == "ownercons":
                      if kbkb["public"] == True:
                        for i in owner:
                            ma = noobcoder.getContact(i)
                            noobcoder.sendMessage(to, None, contentMetadata={'mid': i}, contentType=13)

                    elif cmd.startswith('owner'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if len(list(owner)) < kbkb["limitowner"]:
                                proses = text.split(" ")
                                lcon = text.replace(proses[0] + " lcon", "")
                                if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                                    if "" == lcon:
                                        lcon = "1"
                                    l = int(lcon)
                                    l -= 1
                                    hasil = countLexe(to,"lcon",l)
                                    numb = 0
                                    for s in hasil:
                                        if s in banuser:
                                            noobcoder.sendMessage(to, "User Banned By Creator")
                                        else:
                                            if s not in owner:
                                                aadmin["admins"][s] = True
                                                numb += 1
                                                tx = "Promoted As An Owner:{}".format(str(numb))
                                                foro(to, tx)
                                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded An Owner:\n" +str(noobcoder.getContact(s).displayName))
                                            else:
                                                foro(to, "Already in OwnerList")
                            else:
                                noobcoder.sendMessage(to,"OwnerList is Full")
                                return
                            if len(list(owner)) < kbkb["limitowner"]:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for cust in targets:
                                    if cust in banuser:
                                        noobcoder.sendMessage(to, "User Banned By Creator")
                                    else:
                                        if cust not in owner:
                                            aadmin["admins"][cust] = True
                                            foro(to,"Promoted As An Owner:\n{}".format(noobcoder.getContact(cust).displayName))
                                            noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded A Owner:\n" +str(noobcoder.getContact(cust).displayName))
                                        else:
                                            foro(to, "Already in OwnerList")
                            else:
                                noobcoder.sendMessage(to,"OwnerList is Full")

                    elif cmd.startswith('addowner'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if len(list(owner)) < kbkb["limitowner"]:
                                sep = text.split(" ")
                                search = text.replace(sep[0] + " ","")
                                if search in banuser:
                                    noobcoder.sendMessage(to, "User Banned By Creator")
                                else:
                                    if search in owner:
                                        foro(to, "Already in OwnerList:\n" +str(noobcoder.getContact(search).displayName))
                                    if search not in owner:
                                        noobcoder.findAndAddContactsByMid(search)
                                        aadmin["admins"][search] = True
                                        foro(to, "Promoted As An Owner:\n" +str(noobcoder.getContact(search).displayName))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded A Owner:\n" +str(noobcoder.getContact(search).displayName))
                            else:
                                noobcoder.sendMessage(to,"OwnerList is Full")


                    elif cmd.startswith('addbuyer'):
                        if msg._from in creator or msg._from in seller:
                            if len(list(buyer)) < kbkb["limitbuyer"]:
                                sep = text.split(" ")
                                search = text.replace(sep[0] + " ","")
                                if search in buyer:
                                    foro(to, "Already in BuyerList:\n" +str(noobcoder.getContact(search).displayName))
                                if search not in buyer:
                                    noobcoder.findAndAddContactsByMid(search)
                                    aadmin["owners"][search] = True
                                    foro(to, "Promoted As A Buyer:\n" +str(noobcoder.getContact(search).displayName))
                                    noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded A Buyer:\n" +str(noobcoder.getContact(search).displayName))
                            else:
                                noobcoder.sendMessage(to,"BuyerList is Full")

                    elif cmd.startswith("upbrand "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = removeCmd("upbrand", text)
                            try:
                                setbot["brandname"] = text_
                                foro(to,"Brand Name Changed To :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace brand")


#============================================ SIDER S1 &S2 =========================
                    elif text.lower() == "s2":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            tailah2["siderTemp"][receiver] = []
                            foro(to, "Getting S2...")

                    elif text.lower() == "s1":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            tailah1["siderTemp"][receiver] = []
                            foro(to, "Getting S1...") 

                    elif text.lower() == "sf":
                      if kbkb["public"] == True:
                        if receiver in tailah1["siderTemp"]:
                            del tailah1["siderTemp"][receiver]
                            foro(to, "S1 disabled now.")    
                        if receiver in tailah2["siderTemp"]:
                            del tailah2["siderTemp"][receiver]
                            foro(to, "S2 disabled now.")
                            
                    elif text.lower() == "sider off":
                      if kbkb["public"] == True:
                        if receiver in tailah1["siderTemp"]:
                            del tailah1["siderTemp"][receiver]
                            foro(to, "S1 disabled now.")    
                        if receiver in tailah2["siderTemp"]:
                            del tailah2["siderTemp"][receiver]
                            foro(to, "S2 disabled now.")       

                    elif text.lower() == "s1f":
                      if kbkb["public"] == True:
                        if receiver in tailah1["siderTemp"]:
                            del tailah1["siderTemp"][receiver]
                            foro(to, "S1 disabled now.")    

                    elif text.lower() == "s2f":
                      if kbkb["public"] == True:
                        if receiver in tailah2["siderTemp"]:
                            del tailah2["siderTemp"][receiver]
                            foro(to, "S2 disabled now.")    
#========================================
                    elif cmd.startswith("unsend "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            args = cmd.replace("unsend ","")
                            mes = 0
                            try:
                                mes = int(args)
                            except:
                                mes = 1
                            M = noobcoder.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == noobcoder.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                noobcoder.unsendMessage(id)                                
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join() 
                                
                    elif cmd.startswith("sets1 "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = removeCmd("sets1", text)
                            try:
                                tailah1["siderPesan"] = text_
                                foro(to,"Sider1\nChanged to : " + text_)
                            except:
                                foro(to,"Sider1\nFailed to replace message")

                    elif cmd.startswith("sets2 "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = removeCmd("sets2", text)
                            try:
                                tailah2["siderPesan"] = text_
                                foro(to," Sider2\nChanged to : " + text_)
                            except:
                                foro(to," Sider2\nFailed to replace message")
                                
                    elif cmd.startswith("setreader "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = removeCmd("setreader", text)
                            try:
                                tailah["siderPesan"] = text_
                                foro(to," Reader\nChanged to : " + text_)
                            except:
                                foro(to," Reader\nFailed to replace message")
                    elif cmd.startswith("change app1"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = "1597127494-QDP2OlYl"
                            try:
                                AppLiff["app"] = text_
                                foro(to,"Liff change SucceSs")
                            except:
                                foro(to,"Failed Change Liff")
                    elif cmd.startswith("change app2"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = "1655838636-L03jqlBJ"
                            try:
                                AppLiff["app"] = text_
                                foro(to,"Liff change SucceSs")
                            except:
                                foro(to,"Failed Change Liff")
                    elif cmd.startswith("change app3"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = "1638870522-PnjreV13"
                            try:
                                AppLiff["app"] = text_
                                foro(to,"Liff change SucceSs")
                            except:
                                foro(to,"Failed Change Liff")
                    elif text.lower() == "rn":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            tailah["siderTemp"][receiver] = []
                        #settings['getReader'][receiver]['status'] = True
                            foro(to, "Getting readers...")
                    elif text.lower() == "reader on":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            tailah["siderTemp"][receiver] = []
                        #settings['getReader'][receiver]['status'] = True
                            foro(to, "Getting readers...") 
                    elif text.lower() == "reader off":
                      if kbkb["public"] == True:
                        if receiver in tailah["siderTemp"]:
                            del tailah["siderTemp"][receiver]
                            #settings['getReader'][receiver]['status'] = False
                            foro(to, "Getting readers disabled now.")    
                            
                    elif text.lower() == "rf":
                      if kbkb["public"] == True:
                        if receiver in tailah["siderTemp"]:
                            del tailah["siderTemp"][receiver]
                            #settings['getReader'][receiver]['status'] = False
                            foro(to, "Getting readers disabled now.")    
                            
                    elif cmd.startswith("upname "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            string = removeCmd("upname", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).displayName
                                profile = noobcoder.getProfile()
                                profile.displayName = string
                                noobcoder.updateProfile(profile)
                                foro(to, "Update Name\nStatus : Success\n\nTo :"+str(string))
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nChange helper Name:\n" + string)
                                
                    elif cmd.startswith("upbio "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            string = removeCmd("upbio", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).statusMessage
                                profile = noobcoder.getProfile()
                                profile.statusMessage = string
                                noobcoder.updateProfile(profile)
                                foro(to, "Update Status \nStatus : Success\n\nTo :"+str(string))
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nChange helper Bio:\n" + string)
                                
                    elif cmd.startswith("say "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            sep = text.split(" ")
                            anu = text.replace(sep[0] + " ","")
                            noobcoder.sendMessage(to, anu)

                    elif cmd.startswith("getcon"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            sep = text.split(" ")
                            search = text.replace(sep[0] + " ","")
                            noobcoder.sendContact(to,search)

                    elif text.lower().startswith("conmid "):
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            sep = text.split(" ")
                            search = text.replace(sep[0] + " ","")
                            noobcoder.sendContact(to,search)

                    elif cmd == "groups":
                       if msg._from in creator or msg._from in seller or msg._from in buyer:
                            key = kbkb["keyCommand"].title()
                            if kbkb['setKey'] == False:key = ''
                            gid = noobcoder.getGroupIdsJoined()
                            sd = noobcoder.getGroups(gid)
                            ret = "Group List\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} ({})".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                foro(to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                                
                    elif cmd.startswith('inviteto '):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                                cond = cmd.split(" ")
                                num = int(cond[1])
                                gid = noobcoder.getGroupIdsJoined()
                                group = noobcoder.getCompactGroup(gid[num-1])
                                noobcoder.findAndAddContactsByMid(sender)
                                noobcoder.inviteIntoGroup(gid[num-1],[sender])
                                foro(to, "invited to:\n" + str(group.name))
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nInvite Own A group By Helper:\n"+str(group.name))
                                
                    elif cmd == 'bye':
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            if to not in squad:
                                foro(to, "Allah Hafiz, "+str(noobcoder.getContact(sender).displayName)+"\n"+str(bye["byee"]))
                                noobcoder.leaveGroup(to)             					

#===============================================AUTOJOIN===================
                    elif cmd == "autojoin on":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if settings["autoJoin"] == True:
                                msgs="AUTOJOIN\nJoin already Enabled♪"
                            else:
                                msgs="AUTOJOIN\nJoin set to Enable now♪"
                                settings["autoJoin"] = True
                            foro(to, msgs)
                    elif cmd == "autojoin off":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if settings["autoJoin"] == False:
                                msgs="AUTOJOIN\nJoin already Disabled♪"
                            else:
                                msgs="AUTOJOIN\nJoin set to Disable now♪"
                                settings["autoJoin"] = False
                            foro(to, msgs)

#=============================================

                    elif text.lower() == "ping":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            noobcoder.sendMessage(to, "PONG.") 

                    elif cmd == "here":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            noobcoder.sendMessage(to, "10/10 Bot In Group.") 

                    elif text.lower() == "tagall":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            emoji = kbkb["emoji"]
                            group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                            noobcoder.datamention(to, ' ' + emoji + ' MENTION-LIST ' + emoji + '\n',nama)
                            
                    elif text.lower() == "filter":
                        if kbkb["public"] == True:
                            noobcoder.sendMessage(to, "You Can Turn On/Off Your Filter By Clicking Here\n > line://nv/settings/privacy")
                    elif text.lower() == "liff":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            noobcoder.sendMessage(to, "(Liff 1)\nline://app/1597127494-QDP2OlYl?type=fotext&text=Success_Allow_Liff") 
                            noobcoder.sendMessage(to, "(Liff 2)\nline://app/1655838636-L03jqlBJ?type=fotext&text=Success_Allow_Liff") 
                            noobcoder.sendMessage(to, "(Liff 3)\nline://app/1638870522-PnjreV13?type=fotext&text=Success_Allow_Liff") 
                    elif text.lower() == "price":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            duc1(to,pricelist)
                    elif text.lower() == "creatorcons":
                      if kbkb["public"] == True:
                        for i in creator:
                            ma = noobcoder.getContact(i)
                            noobcoder.sendMessage(to, None, contentMetadata={'mid': i}, contentType=13)



                    elif text.lower() == "mycon":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            ma = noobcoder.getContact(sender)
                            noobcoder.sendMessage(to, None, contentMetadata={'mid': sender}, contentType=13)       

                    elif cmd == "allowliff":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            try:
                                allowLiff()
                                foro(to,"Flex Mode Enable")
                            except:
                                noobcoder.sendMessage(msg.to,"Faild!") 
                    elif text.lower() == "creator":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            ZURAIZ = noobcoder.getContact(sender).displayName
                            noobcoder.sendMessage(to,"Hello, {}\nThanks For Your Interest\nIf You Want Protect Bot, War Bot, Selfbot,Self-War Or Kicker Contact My Creator!\n\nCreator's I'd\nhttps://tinyurl.com/2hrabq9q\nhttps://tinyurl.com/2malgxpw".format(ZURAIZ))

                    elif text.lower().startswith("cover "):
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            if noobcoder != None:
                                if 'MENTION' in msg.contentMetadata != None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        path = noobcoder.getProfileCoverURL(ls)
                                        path = str(path)
                                        noobcoder.generateReplyMessage(msg.id)
                                        noobcoder.sendReplyImageWithURL(msg.id, to, str(path))
                    elif text.lower().startswith("name "):
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            if 'MENTION' in msg.contentMetadata != None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.generateReplyMessage(msg.id)
                                    noobcoder.sendReplyMessage(msg.id, to, "{}".format(str(contact.displayName)))
                    elif text.lower().startswith("bio "):
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            if 'MENTION' in msg.contentMetadata != None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.generateReplyMessage(msg.id)
                                    noobcoder.sendReplyMessage(msg.id, to, "{}".format(str(contact.statusMessage)))
                    elif text.lower().startswith("profile "):
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            if 'MENTION' in msg.contentMetadata != None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    cu = noobcoder.getProfileCoverURL(ls)
                                    path = str(cu)
                                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                    noobcoder.sendMessage(msg.to,"Nama :\n" + contact.displayName + "\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage)
                                    noobcoder.sendImageWithURL(msg.to,image)
                                    noobcoder.sendImageWithURL(msg.to,path)    
                    elif text.lower().startswith("contact "):
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            if 'MENTION' in msg.contentMetadata != None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    mi_d = contact.mid
                                    noobcoder.sendContact(to, mi_d)            
                    elif text.lower() == "mymid":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to, ""+str(sender))                 
                    elif text.lower().startswith("getmid "):
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            if 'MENTION' in msg.contentMetadata != None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                ret_ = ""
                                for ls in lists:
                                    ret_ += "{}".format(str(ls))
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to, str(ret_))

#==========================================
                    elif cmd.startswith("autojoin set "):
                        if msg._from in buyer or msg._from in creator:
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            wait["Members"] = int(msg.text.split(" ")[2])
                            foro(msg.to, "Autojoin LimiT\nType: Minimum Members\nStatus: Successful Set\nTo: {} Members".format(wait["Members"]))
                    
                    elif cmd == "screens":
                    	if msg._from in buyer or msg._from in creator or msg._from in seller:
                            proses = os.popen("screen -list")
                            a = proses.read()
                            noobcoder.sendMessage(to, "{}\n👑ZURAIZ一Bots👑".format(str(a)))
                            proses.close()
#==========================================
#==========================================
#==========================================
                    elif cmd == "about":
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            arr = []
                            today = datetime.today()
                            thn = 2018 
                            bln = 8    #isi bulannya yg sewa
                            hr = 9   #isi tanggalnya yg sewa
                            future = datetime(thn, bln, hr)
                            days = (str(future - today))
                            comma = days.find(",")
                            days = days[:comma]
                            gid = noobcoder.getGroupIdsJoined()
                            total = len(gid)
                            gid2 = noobcoder.getGroupIdsInvited()
                            total2 = len(gid2)
                            h = noobcoder.getContact(noobcoderMID)
                            contactlist = noobcoder.getAllContactIds()
                            kontak = noobcoder.getContacts(contactlist)
                            favorite = noobcoder.getFavoriteMids()
                            fil = noobcoder.getSettings().privacyReceiveMessagesFromNotFriend
                            seal = noobcoder.getSettings().e2eeEnable
                            blockedlist = noobcoder.getBlockedContactIds()
                            src = noobcoder.getSettings().privacySearchByUserid
                            kontak2 = noobcoder.getContacts(blockedlist)
                            status = {"kick": "", "invite": ""}
                            try:noobcoder.inviteIntoGroup(to, [noobcoderMID]);status["kick"] = "Normal "
                            except:status["kick"] = "banned "
                            try:noobcoder.inviteIntoGroup(to, [noobcoderMID]);status["invite"] = "Normal "
                            except:status["invite"] = "banned "
                            if src == True:alid = "Add From LineID: True"
                            else:alid = "Add From LineID: False"                            
                            if seal == True:letsel = "Letter Sealing: True"
                            if seal == False:letsel = "Letter Sealing: False"
                            if fil == True:fpes = "Filter Message: False"
                            if fil == False:fpes = "Filter Message: True"
                            mc = "     𝐀𝐁𝐎𝐔𝐓\n"
                            mc += "🥂 ZURAIZ BOTS 🥂\n"
                            mc += "\n01 > Name: {}".format(h.displayName)
                            mc += "\n02 > User Location: PAK"
                            mc += "\n03 > User Lineid: {}".format(noobcoder.profile.userid)
                            mc += "\n04 > Total Groups: {}".format(total)
                            mc += "\n05 > Total Pending: {}".format(total2)
                            mc += "\n06 > Total Friend: {}".format(str(len(kontak)))
                            mc += "\n07 > Total Favorite: {}".format(str(len(favorite)))
                            mc += "\n08 > Total Blocked: {}".format(str(len(kontak2)))
                            if kbkb["add"] == True:mc += "\n09 > AutoAdd: On"
                            else:mc += "\n09 > AutoAdd: Off"
                            mc += "\n10 > Chat send: {}".format(str(peler["sendcount"]))
                            mc += "\n11 > Chat received: {}".format(str(peler["receivercount"]))
                            mc += "\n12 > {}".format(alid)
                            mc += "\n13 > {}".format(letsel)
                            mc += "\n14 > {}".format(fpes)
                            mc += "\n15 > Kick: %s" % status["invite"]
                            mc += "\n16 > Invite: %s" % status["invite"]
                            mc += "\n17 > New Message: On."
                            mc += "\n18 > Group Invitation: On."
                            mc += "\n19 > Show Message: On."
                            mc += "\n20 > Incoming Call: On."
                            mc += "\n21 > Sync Contact: On."
                            mc += "\n22 > Mention Notify: On."
                            mc += "\n23 > Device Login: On."
                            mc += "\n𝐕𝐄𝐑𝐒𝐈𝐎𝐍:  3.75.0"
                            foro(to, mc)

#==========================================
#==========================================
                    elif cmd == "speed":
                       if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            speed(to, debug())

                    elif cmd == "reboot":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            foro(to, "💕 "+noobcoder.getContact(sender).displayName+"\nSystem Rebooting...")
                            restartBot()
                        else:pass
                    if text.lower() == "login sb" and msg._from not in premium["myService"]:
                      if kbkb["public"] == True:
                        noobcoder.sendMention(to, 'Status : Failed\n> Sorry @!\nYou Are Not In  Premium List\n\nCotact id> http://line.me/ti/p/~aryan1232',' ', [msg._from])

#==================new updated by ZURAIZ========================
                    elif cmd == "logmode on":
                        if msg._from in creator or msg._from in seller:
                            kbkb["squad"] = str(to)
                            foro(to,"Logmode set to On for this Group! \n This is the Logmode Room Now!")

                    elif cmd == "upimage":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            kbkb["changePicture"] = True
                            foro(to, "Send a photo.")

                    elif cmd == "upcover":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            kbkb["changeCover"] = True
                            foro(to, "Send a photo.")

                    elif cmd.startswith("setbye "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = removeCmd("setbye", text)
                            try:
                                bye["byee"] = text_
                                foro(to,"Bye msg successful set :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace Byemsg")

                    elif cmd == "welcomemsg on":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["welcome"] == True:
                                msgs="Welcome Msg already Enabled♪"
                            else:
                                msgs="Welcome Msg Enable Now♪"
                                kbkb["welcome"] = True
                            foro(to, msgs)
                    elif cmd == "welcomemsg off":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["welcome"] == False:
                                msgs="Welcome Msg already Disabled♪"
                            else:
                                msgs="Welcome Msg Disable Now♪"
                                kbkb["welcome"] = False
                            foro(to, msgs)

                    elif cmd.startswith("setwelcome "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = removeCmd("setwelcome", text)
                            try:
                                welcome["welcomee"] = text_
                                foro(to,"Welcome msg successful set :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace Welcomemsg")

                    elif cmd.startswith("groupcast "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            txt = removeCmd("groupcast", text)
                            groups = noobcoder.getGroupIdsJoined()
                            for group in groups:
                                foro(group, " Group Broadcast \n\n" +str(txt))
                                time.sleep(2)
                            foro(to, "Successful broadcast to {} group".format(str(len(groups))))
                            noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nGroup cast")

                    if cmd.startswith('gleave '):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("gleave", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    if G.id not in squad:
                                        noobcoder.leaveGroup(G.id)
                                except:
                                    noobcoder.leaveGroup(G.id)
                                foro(to, "Successfully left:\n" + G.name)
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nLeave Helper From:\n" + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))

                    elif cmd.startswith("memlist "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("memlist", text)
                            groups = noobcoder.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = noobcoder.getGroup(group)
                            nama = [contact.mid for contact in G.members]
                            nama.remove(noobcoder.getProfile().mid)
                            noobcoder.datamention(to,' MEMBERS-LIST\n ' ,nama)

                    elif cmd.startswith("penlist "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("penlist", text)
                            groups = noobcoder.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = noobcoder.getGroup(group)
                            nama = [contact.mid for contact in G.invitee]
                            noobcoder.datamention(to,' PENDING-LIST\n ' ,nama)
                                      
                    elif cmd.startswith("getlink "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("getlink", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                noobcoder.sendMessage(to, "Open Qr \n\n Group : " + G.name + "\n Link: " + gurl)
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nOpen Group Qr:\nGroup Name: " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))

                    elif cmd.startswith("closeqr "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("closeqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = True
                                    noobcoder.updateGroup(G)
                                except:
                                    G.preventedJoinByTicket = True
                                    noobcoder.updateGroup(G)
                                foro(to, "Close Qr \n\n Group : " + G.name)
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nClose Group Qr:\nGroup Name: " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))

                    elif cmd.startswith("upapi "):
                        if msg._from in creator or msg._from in seller:
                            text_ = removeCmd("upapi", text)
                            try:
                                kbkb["apikey"] = text_
                                foro(to,"Apikey updated:\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace Apikey")

                    elif cmd == 'clearbuyers':
                        if msg._from in creator or msg._from in seller:
                            aadmin["owners"].clear()
                            foro(to,"Cleared all Buyers")
                            noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nClear All Buyers")

                    elif cmd == 'clearowners':
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            aadmin["admins"].clear()
                            foro(to,"Cleared all Owners")
                            noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nClear All Owners")

                    elif cmd.startswith('upprefix'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            split = text.split(" ")
                            prefix = split[1]
                            kbkb["prefix"] = prefix
                            kbkb["keyCommand"] = prefix
                            foro(to,"Prefix set to ({})".format(prefix))

                    elif text.lower() == "prefix":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            prefix = kbkb["prefix"]
                            noobcoder.sendMessage(to,"{}".format(prefix))

                    elif text.lower() == "rname":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            prefix = kbkb["prefix"]
                            noobcoder.sendMessage(to,"{}".format(prefix))

                    elif cmd == "menu":
                        if msg._from in creator or msg._from in seller:
                            helpMessage = helpcreator()
                            menu(to, str(helpMessage))

                    elif cmd == "help":
                        if msg._from in buyer:
                            helpMessage = helpbuyer()
                            menu(to, str(helpMessage))
                        if msg._from in owner:
                            helpMessage = helpowner()
                            menu(to, str(helpMessage))

                    elif text.lower() == "help":
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            helpMessage = helppublic()
                            noobcoder.sendMessage(to, str(helpMessage))

                    elif cmd == "help buyers":
                        if msg._from in creator or msg._from in seller:
                            helpMessage = helpbuyer()
                            menu(to, str(helpMessage))

                    elif cmd == "help owners":
                        if msg._from in creator or msg._from in seller:
                            helpMessage = helpowner()
                            menu(to, str(helpMessage))


                    elif cmd.startswith("delbuyer "):
                        if msg._from in creator or msg._from in seller:
                            h = [a for a in aadmin["owners"]]
                            mid = h[int(text.lower().split(' ')[1])-1]
                            if mid in aadmin["owners"]:
                                del aadmin["owners"][mid]
                                foro(to, "Expelled From BuyerList\n" +str(noobcoder.getContact(mid).displayName))
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved From Buyer:\n" +str(noobcoder.getContact(mid).displayName))

                    elif cmd.startswith("delowner "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            h = [a for a in aadmin["admins"]]
                            mid = h[int(text.lower().split(' ')[1])-1]
                            if mid in aadmin["admins"]:
                                del aadmin["admins"][mid]
                                foro(to, "Expelled From OwnerList\n" +str(noobcoder.getContact(mid).displayName))
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved From Owner:\n" +str(noobcoder.getContact(mid).displayName))

                    elif cmd.startswith("ban"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            proses = text.split(" ")
                            lcon = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                                if "" == lcon:
                                    lcon = "1"
                                l = int(lcon)
                                l -= 1
                                num = 0
                                hasil = countLexe(to,"lcon",l)
                                for s in hasil:
                                    if s not in banuser:
                                        banuser.append(s)
                                        num += 1
                                        foro(to, "Promoted ({}) Contact to banuser.".format(num))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded A Banuser:\n" +str(noobcoder.getContact(s).displayName))
                                    else:
                                        foro(to, "Already In BanList.")
                                        return
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            num = 0
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for cust in targets:
                                if cust not in banuser:
                                    banuser.append(cust)
                                    num += 1
                                    foro(to,"Promoted ({}) Contact to banuser.".format(num))
                                    noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nAdded A Banuser:\n" +str(noobcoder.getContact(cust).displayName))
                                else:
                                    foro(to, "Already In BanList.")

                    elif cmd.startswith("unban"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            proses = text.split(" ")
                            lcon = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                                if "" == lcon:
                                    lcon = "1"
                                l = int(lcon)
                                l -= 1
                                num = 0
                                hasil = countLexe(to,"lcon",l)
                                for s in hasil:
                                    if s in banuser:
                                        banuser.remove(s)
                                        num += 1
                                        foro(to, "Removed ({}) Contact By Banuser.".format(num))
                                        noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved From Banuser:\n" +str(noobcoder.getContact(s).displayName))
                                    else:
                                        foro(to, "Not In BanList.")
                                        return
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            num = 0
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for cust in targets:
                                if cust in banuser:
                                    banuser.remove(cust)
                                    num += 1
                                    foro(to,"Removed ({}) Contact By Banuser.".format(num))
                                    noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nRemoved From Banuser:\n" +str(noobcoder.getContact(cust).displayName))
                                else:
                                    foro(to, "Not In BanList.")

                    elif cmd.startswith("ginfo"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            sep = msg.text.split(" ")
                            num = msg.text.replace(sep[0] + " ","")
                            gids = noobcoder.getGroupIdsJoined()
                            gid = gids[int(num) - 1]
                            group = noobcoder.getCompactGroup(gid)
                            try:
                                ccreator = group.creator.mid
                                gcreator = group.creator.displayName
                            except:
                                ccreator = None
                                gcreator = 'Tidak Ditemukan'
                            if not group.invitee:
                                pendings = 0
                            else:
                                pendings = len(group.invitee)
                            qr = 'Close' if group.preventedJoinByTicket else 'Open'
                            if group.preventedJoinByTicket:
                                ticket = 'Not found'
                            else:
                                ticket = 'https://line.me/R/ti/g/' + str(noobcoder.reissueGroupTicket(group.id))
                            created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
                            path = 'https://obs.line-scdn.net/' + group.pictureStatus
                            res = "Remoted Group Info"
                            res += '\n	 > Group ID : ' + group.id
                            res += '\n	 > Group Name : ' + group.name
                            res += '\n	 > Group Creator : ' + gcreator
                            res += '\n	 > Created Time : ' + created
                            res += '\n	 > Member Count : ' + str(len(group.members))
                            res += '\n	 > Pending Count : ' + str(pendings)
                            res += '\n	 > QR Status : ' + qr
                            res += '\n	 > Ticket : ' + ticket
                            noobcoder.sendReplyImageWithURL(msg_id, to, path)
                            if ccreator:
                                noobcoder.sendReplyMessage(msg_id, to, None, contentMetadata={'mid': ccreator}, contentType=13)
                            noobcoder.sendMessage(to, res)
                            
                    elif cmd.startswith("mentionall"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            sep = msg.text.split(" ")
                            num = msg.text.replace(sep[0] + " ","")
                            gids = noobcoder.getGroupIdsJoined()
                            gid = gids[int(num) - 1]
                            G = noobcoder.getGroup(gid)
                            group = noobcoder.getGroup(gid);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                            emoji = kbkb["emoji"]
                            noobcoder.datamention(gid,' ' + emoji + ' MENTION-LIST ' + emoji + ' ', nama)
                            noobcoder.sendReplyMessage(msg_id, to, 'Successful Remote Mentionall\nIn Group: ' +  str(G.name))

                    elif cmd.startswith('gkick'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            cond = cmd.split(" ")
                            num = int(cond[1])
                            gid = noobcoder.getGroupIdsJoined()
                            group = noobcoder.getCompactGroup(gid[num-1])
                            ZURAIZ = kick["kicker"]
                            noobcoder.kickoutFromGroup(gid[num-1], ZURAIZ)
                            kick["kicker"].clear

                    elif cmd.startswith('addgkick'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            kbkb["kicker"] = True
                            noobcoder.sendMessage(to, "Send Contact")
                            
                    elif cmd == 'flex on':
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            kbkb["flex"] = True
                            kbkb["chat"] = False
                            foro(to,"Flex Enabled.")

                    elif cmd == 'flex off':
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            kbkb["flex"] = False
                            kbkb["chat"] = True
                            foro(to,"Flex Disabled.")

#==========================================
                    elif cmd == "listlogins":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            num = 0
                            mc = "⌬ 𝐒𝐛 𝐥𝐨𝐠𝐢𝐧 ⌬\n"
                            for mid in sblogin:
                                num += 1
                                mc += "{}. {}\n".format(str(num),noobcoder.getContact(mid).displayName)
                            noobcoder.sendMessage(to,mc)

                    elif cmd.startswith("memcon "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("memcon", text)
                            groups = noobcoder.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = noobcoder.getGroup(group)
                            nama = [contact.mid for contact in G.members]
                            for s in nama:
                                noobcoder.sendContact(to, s)

                    elif cmd.startswith("pencon "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("pencon", text)
                            groups = noobcoder.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = noobcoder.getGroup(group)
                            nama = [contact.mid for contact in G.invitee]
                            for s in nama:
                                noobcoder.sendContact(to, s)
                                      
                    elif cmd == 'invited':
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = noobcoder.getGroupIdsInvited()
                            sd = noobcoder.getGroups(gid)
                            ret = "> Invited <\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal: {} Invited(s)".format(total)
                            for G in sd:
                                no += 1
                                ret += "\n{}. {}".format(no, G.name[0:50])
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                noobcoder.sendMessage(to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))

                    if cmd.startswith('accept '):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("accept", text)
                            groups = noobcoder.getGroupIdsInvited()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.acceptGroupInvitation(G.id)
                                except:
                                    noobcoder.acceptGroupInvitation(G.id)
                                noobcoder.sendMessage(to, "Accepted Group:\n\n" + G.name)
                            except Exception as error:
                                foro(to, str(error))

                    elif cmd.startswith("decline "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            number = removeCmd("decline", text)
                            groups = noobcoder.getGroupIdsInvited()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.rejectGroupInvitation(G.id)
                                except:
                                    noobcoder.rejectGroupInvitation(G.id)
                                noobcoder.sendMessage(to, "Declined for:\n\n" + G.name)
                                noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\nReject Group Invitation:\n" + G.name)
                            except Exception as error:
                                foro(to, str(error))

                    elif cmd.startswith("limitsb "):
                        if msg._from in creator or msg._from in seller:
                            sep = removeCmd("limitsb", text)
                            kbkb["limitsb"] = int(sep)
                            noobcoder.sendMessage(to,"Successful LimitSelfbot Changed to : "+sep)

                    elif cmd.startswith("limitbuyer "):
                        if msg._from in creator or msg._from in seller:
                            sep = removeCmd("limitbuyer", text)
                            kbkb["limitbuyer"] = int(sep)
                            noobcoder.sendMessage(to,"Successful LimitBuyer Changed to : "+sep)

                    elif cmd.startswith("limitowner "):
                        if msg._from in creator or msg._from in seller:
                            sep = removeCmd("limitowner", text)
                            kbkb["limitowner"] = int(sep)
                            noobcoder.sendMessage(to,"Successful LimitOwner Changed to : "+sep)

                    elif cmd == "autoadd off":
                        if msg._from in creator or msg._from in seller:
                            if kbkb["add"] == False:
                                msgs="Autoadd already disabled."
                            else:
                                msgs="Autoadd disable now."
                                kbkb["add"]=False
                            foro(to, msgs)
                    elif cmd == "autoadd on":
                        if msg._from in creator or msg._from in seller:
                            if kbkb["add"] == True:
                                msgs="Autoadd already enabled."
                            else:
                                msgs="Autoadd enable now."
                                kbkb["add"]=True
                            foro(to, msgs)

                    elif cmd.startswith("setadd "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = removeCmd("setadd", text)
                            try:
                                kbkb["addmsg"] = text_
                                noobcoder.sendMessage(to,"Changed to :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to Replace Addmsg")


                    elif cmd == "autoread on":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["read"] == True:
                                msgs="Auto Read Already Enabled."
                            else:
                                msgs="Auto Read Enable Now."
                                kbkb["read"] = True
                            foro(to, msgs)
                    elif cmd == "autoread off":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["read"] == False:
                                msgs="Auto Read Already Disabled."
                            else:
                                msgs="Auto Read Disable Now."
                                kbkb["read"] = False
                            foro(to, msgs)

                    elif cmd == "leavemsg on":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["leave"] == True:
                                msgs="Leavemsg Already Enabled."
                            else:
                                msgs="Leavemsg Enable Now."
                                kbkb["leave"] = True
                            foro(to, msgs)
                    elif cmd == "leavemsg off":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["leave"] == False:
                                msgs="Leavemsg Already Disabled."
                            else:
                                msgs="Leavemsg Disable Now."
                                kbkb["leave"] = False
                            foro(to, msgs)

                    elif cmd.startswith("setleave "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            text_ = removeCmd("setleave", text)
                            try:
                                kbkb["leavemsg"] = text_
                                noobcoder.sendMessage(to,"Changed to :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace Leavemsg")

                    elif cmd == 'clearbans':
                        if msg._from in creator or msg._from in seller:
                            kbkb['ban'].clear()
                            foro(to,"Cleared BanList")
                            noobcoder.sendMessage(squad, "Command user : "+str(noobcoder.getContact(sender).displayName)+"\n\ncleared Banlist")

                    elif cmd == 'clearchats':
                        if msg._from in creator or msg._from in seller:
                            try:
                                noobcoder.removeAllMessages(op.param2)
                                foro(to,"Removed All Chat Msg.")
                            except:
                                noobcoder.removeAllMessages(to)
                                foro(to,"Removed All Chat Msg.")

                    elif cmd == 'clearcaches':
                        if msg._from in creator or msg._from in seller:
                            try:
                                os.system('sync; echo 3 > /proc/sys/vm/drop_caches')
                                time.sleep(2)
                                foro(to,"Cleared Caches in Server.")
                            except:pass

                    elif cmd == "leaveall":
                       if msg._from in creator or msg._from in seller:
                            key = kbkb["keyCommand"].title()
                            if kbkb['setKey'] == False:key = ''
                            gid = noobcoder.getGroupIdsJoined()
                            sd = noobcoder.getGroups(gid)
                            ret = "Successful Leave\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                for a in gid:
                                    if a not in squad:
                                        noobcoder.leaveGroup(a)
                                foro(to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                                

                    elif cmd == "runtime":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            timeNow = time.time()
                            runtime = timeNow - botStart
                            runtime = format_timespan(runtime)
                            foro(to, "{}".format(runtime))

                    elif cmd.startswith("lastseen "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                if target in seens["find"]:
                                    mentions2(msg.to, "@! "+seens["username"][target], [target])
                                else:
                                    mentions2(msg.to, "@! \n not found in any groups.", [target])
                                    print(seens)

                    elif cmd.startswith("midlastseen"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            sep = text.split(" ")
                            search = text.replace(sep[0] + " ","")
                            if search in seens["find"]:
                                mentions2(msg.to, "@! "+seens["username"][search], [search])
                            else:
                                mentions2(msg.to, "@! \n not found in any groups.", [search])
                                print(seens)

                    elif cmd == "abort":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["changePicture"] == True:
                                kbkb["changePicture"] = False
                                noobcoder.sendMessage(to, "Aborted upimage command.")
                            if kbkb["changeCover"] == True:
                                kbkb["changeCover"] = False
                                noobcoder.sendMessage(to, "Aborted upcover command.")
                            if kbkb["kicker"] == True:
                                kbkb["kicker"] = False
                                noobcoder.sendMessage(to, "Aborted gkick command.")

                    elif cmd == 'friendlist':
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            a = noobcoder.refreshContacts()
                            noobcoder.datamention(msg.to,'List Friend',a)

                    elif cmd == "clearfriends":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            n = len(noobcoder.getAllContactIds())
                            try:
                                noobcoder.clearContacts()
                            except: 
                                pass
                            t = len(noobcoder.getAllContactIds())
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to," Before: %s friends.\n After: %s friends.\n Removed: %s friends."%(n,t,(n-t)))

                    elif cmd == "addme":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            contact = noobcoder.getContact(sender)
                            noobcoder.findAndAddContactsByMid(sender)
                            noobcoder.sendMessage(to, "{} , has been added to friendlist.".format(contact.displayName))

                    elif cmd.startswith("midfriend"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            sep = text.split(" ")
                            search = text.replace(sep[0] + " ","")
                            contact = noobcoder.getContact(search)
                            noobcoder.findAndAddContactsByMid(search)
                            noobcoder.sendMessage(to, "{} , has been added to friendlist.".format(contact.displayName))

                    elif cmd.startswith("addfriend"):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.findAndAddContactsByMid(ls)
                                noobcoder.sendMessage(to, "{} , has been added to friendlist.".format(contact.displayName))

                    elif cmd == "leavechat on":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["leavechat"] == True:
                                msgs="Auto leave chat Already Enabled."
                            else:
                                msgs="Auto leave chat Enable Now."
                                kbkb["leavechat"] = True
                            foro(to, msgs)
                    elif cmd == "leavechat off":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["leavechat"] == False:
                                msgs="Auto leave chat Already Disabled."
                            else:
                                msgs="Auto leave chat Disable Now."
                                kbkb["leavechat"] = False
                            foro(to, msgs)

                    elif cmd == "print on":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if to in kbkb["print"]:
                                noobcoder.sendMessage(msg.to, "Flex Detect  already enabled")
                            else:
                                kbkb["print"].append(to)
                                noobcoder.sendMessage(msg.to, "Flex Detect enabled now.")

                    elif cmd == "print off":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if to not in kbkb["print"]:
                                noobcoder.sendMessage(msg.to, "Flex Detect  already disabled.")
                            else:
                                kbkb["print"].remove(to)
                                noobcoder.sendMessage(msg.to, "Flex Detect disabled now.")

                    elif cmd == "flexroom on":
                        if msg._from in creator or msg._from in seller:
                            kbkb['flexroom'] = str(to)
                            noobcoder.sendMessage(to,"FlexRoom set to On for this Group! \n This is the Flex Room Now!")

                    elif cmd == "public on":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["public"] == True:
                                msgs="Public Cmd Already Enable Now."
                            else:
                                msgs="Public Cmd Enable Now."
                                kbkb["public"] = True
                            foro(to, msgs)
                    elif cmd == "public off":
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            if kbkb["public"] == False:
                                msgs="Public Cmd Already Disable Now."
                            else:
                                msgs="Public Cmd Disable Now."
                                kbkb["public"] = False
                            foro(to, msgs)

                    elif cmd == "stats":
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            buyerr = aadmin["owners"]
                            b1 = len(buyerr)
                            ownerr = aadmin["admins"]
                            b2 = len(ownerr)
                            bann = kbkb['ban']
                            b3 = len(bann)
                            ttt = premium['listLogin']
                            b4 = len(ttt)
                            kkk = premium['myService']
                            b5 = len(kkk)
                            gid = noobcoder.getGroupIdsJoined()
                            total = len(gid)
                            friends = noobcoder.getAllContactIds()
                            tfriends = len(friends)
                            blockeds = noobcoder.getBlockedContactIds()
                            block = len(blockeds)
                            mc = "DATABASE\n"
                            mc += "\n> Buyers : {}/".format(str(b1))
                            mc += "{}".format(kbkb["limitbuyer"])
                            mc += "\n> Owners : {}/".format(str(b2))
                            mc += "{}".format(kbkb["limitowner"])
                            mc += "\n> Banned : {}".format(str(b3))
                            mc += "\n> Sb Login : {}".format(str(b4))
                            mc += "\n> Sb Total : {}".format(str(b5))
                            mc += "\n> Groups : {}".format(str(total))
                            mc += "\n> Friends : {}".format(str(tfriends))
                            mc += "\n> Blocked : {}".format(str(block))
                            mc += "\n> Total Sb Limit : {}".format(kbkb["limitsb"])
                            noobcoder.sendMessage(to,mc)

                    elif cmd.startswith("locate "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                G = noobcoder.getGroupIdsJoined()
                                cgroup = noobcoder.getGroups(G)
                                groups = noobcoder.groups
                                ngroup = ""
                                ngroup += "Located in\n\n"
                                no = 0 + 1
                                num = 0
                                for mention in targets:
                                    for x in range(len(cgroup)):
                                        gMembMids = [contact.mid for contact in cgroup[x].members]
                                        if mention in gMembMids:
                                            ngroup += "\n> {}".format(str(cgroup[x].name))
                                            no += 1
                                            num += 1
                                    ngroup += " \n Total ({}) group.".format(str(num))
                                    noobcoder.sendMessage(to, str(ngroup))
                                if ngroup == "":
                                    noobcoder.sendMessage(to, "Not found.")

                    elif cmd.startswith("upcbrand "):
                        if msg._from in creator or msg._from in seller:
                            text_ = removeCmd("upcbrand", text)
                            try:
                                kbkb["cmenubrand"] = text_
                                noobcoder.sendMessage(to,"Changed to :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace message")

                    elif cmd.startswith("upemoji "):
                        if msg._from in creator or msg._from in seller:
                            text_ = removeCmd("upemoji", text)
                            try:
                                kbkb["emoji"] = text_
                                noobcoder.sendMessage(to,"Changed to :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace message")

                    elif cmd.startswith("uppbrand "):
                        if msg._from in creator or msg._from in seller:
                            text_ = removeCmd("uppbrand", text)
                            try:
                                kbkb["pmenubrand"] = text_
                                noobcoder.sendMessage(to,"Changed to :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace message")

                    elif cmd.startswith("upbbrand "):
                        if msg._from in creator or msg._from in seller:
                            text_ = removeCmd("upbbrand", text)
                            try:
                                kbkb["bmenubrand"] = text_
                                noobcoder.sendMessage(to,"Changed to :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace message")

                    elif cmd.startswith("upobrand "):
                        if msg._from in creator or msg._from in seller:
                            text_ = removeCmd("upobrand", text)
                            try:
                                kbkb["omenubrand"] = text_
                                noobcoder.sendMessage(to,"Changed to :\n" + text_)
                            except:
                                noobcoder.sendMessage(to,"Failed to replace message")

                    elif cmd.startswith("friendcast "):
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            txt = removeCmd("friendcast", text)
                            friends = noobcoder.getAllContactIds()
                            for friend in friends:
                                noobcoder.sendMessage(friend, " Friend Broadcast \n\n{}"+str(txt))
                                time.sleep(2)
                                noobcoder.sendMessage(to, "Succesful broadcast to {} friend".format(str(len(friends))))

                    elif cmd == "nukeall":
                        if msg._from in creator or msg._from in seller:
                            x = noobcoder.getGroup(msg.to)
                            anu = x.id
                            nami = [contact.mid for contact in x.members]
                            targetk = []
                            for a in nami:
                                if a not in creator and a not in buyer and a not in owner:
                                    targetk.append(a)
                            cms = 'style.js gid={} token={} app={}'.format(anu,noobcoder.authToken,appF)
                            for y in targetk:
                                cms += ' uid={}'.format(y)
                            print(cms)
                            success = execute_js(cms)

                    elif cmd.startswith("bypass "):
                        if msg._from in creator or msg._from in seller:
                            number = removeCmd("bypass", text)
                            groups = noobcoder.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = noobcoder.getGroup(group)
                            anu = G.id
                            nami = [contact.mid for contact in G.members]
                            targetk = []
                            for a in nami:
                                if a not in creator and a not in buyer and a not in owner:
                                    targetk.append(a)
                            cms = 'style.js gid={} token={} app={}'.format(anu,noobcoder.authToken,appF)
                            for y in targetk:
                                cms += ' uid={}'.format(y)
                            print(cms)
                            success = execute_js(cms)
                            if success:
                               noobcoder.sendMessage(msg.to,"Succes Baypass \n " + str(G.name))
                            else:
                               noobcoder.sendMessage(msg.to,"Limit Bose")
                               
                    elif cmd == "cancelall":
                        if msg._from in creator or msg._from in seller:
                            x = noobcoder.getGroup(msg.to)
                            anu = x.id
                            if x.invitee is None or x.invitee == []:
                                  noobcoder.sendMessage(to, "Nothing")
                            nami = [contact.mid for contact in x.invitee]
                            targetk = []
                            for a in nami:
                                if a not in creator and a not in seller and a not in buyer and a not in owner:
                                    targetk.append(a)
                            cms = 'style.js gid={} token={} app={}'.format(anu,noobcoder.authToken,appF)
                            for y in targetk:
                                cms += ' cid={}'.format(y)
                            print(cms)
                            success = execute_js(cms)

                    elif cmd.startswith("lurkgc "):
                        if msg._from in creator or msg._from in seller:
                            number = removeCmd("lurkgc", text)
                            groups = noobcoder.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            G = noobcoder.getGroup(group)
                            kbjani = G.id
                            tailah["siderTemp"][kbjani] = []
                            foro(to, "Getting Lurk GC...")

                    elif cmd.startswith('addday'):
                        if msg._from in creator or msg._from in seller:
                            split = text.split(" ")
                            days = text.replace(split[0] + " ","")
                            today = datetime.now(tz=pytz.timezone("Asia/Karachi"))
                            kbkb["duedate"] = str(today+timedelta(int(days)))
                            noobcoder.sendMessage(to,f"Set duedate to {days} Days\nDuedate : {parser.parse(kbkb['duedate']).strftime('%d-%m-%Y (%H:%M:%S)')}")

                    elif text.lower() == "lurk on":
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            if to in wait['readPoint']:
                                foro(to, "Lurk\nLurk already set")
                            else:
                                try:
                                    del wait['readPoint'][to];del wait['setTime'][to]
                                except:
                                    pass
                                wait['readPoint'][to] = msg.id;wait['setTime'][to]  = {};wait['ROM1'][to] = {}
                                foro(to, "Lurk\nLurk point set")
                    elif text.lower() == "lurk off":
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            if msg.to not in wait['readPoint']:
                                foro(to, "Lurk\nLurk already off")
                            else:
                                try:
                                   del wait['readPoint'][to];wait['setTime'][to] = {};wait['ROM1'][to] = {}
                                except:
                                   pass
                                foro(to, "Lurk\nLurk point off")
                    elif text.lower() == "lurk result":
                        if msg._from in creator or msg._from in seller or msg._from in buyer or msg._from in owner:
                            if to in wait['readPoint']:
                                try:
                                    anulurk(to,wait)
                                    wait['setTime'][to]  = {}
                                except:foro(to,'Lurkers\nNone')
                            else:foro(to, "Lurk\nLurk point not on")

#=================================================QR UPDATED BY ZURAIZ KHAN ============================
                    elif text.lower() == "login war" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                user = premium["myService"][msg._from]
                                try:
                                    def kentod():
                                        qr = shahzi.LineGetQr("DESKTOPMAC\t7.5.0\tmacOS\t11.6")
                                        noobcoder.sendMessage(to, "Link QR: "+qr["result"]["qrlink"])
                                        noobcoder.sendImageWithURL(to, qr["result"]["qrcode"])
                                        pincode = shahzi.lineGetQrPincode(qr["result"]["session"])
                                        noobcoder.sendMessage(to, "Your Pincode: "+pincode["result"])
                                        auth = shahzi.lineGetQrAuth(qr["result"]["session"])
                                        authToken,cert = auth["result"]["accessToken"],auth["result"]["certificate"]
                                        zzz = authToken
                                        yyy = cert
                                        if msg._from not in premium['listLogin']:
                                            premium['listLogin'][msg._from] =  '%s' % user
                                            isi = "{}".format(zzz)
                                            os.system('cp -r loginwar {}'.format(user))
                                            os.system('cd {} && echo -n "{}" > token.txt'.format(user, isi))
                                            os.system('screen -dmS {}'.format(user))
                                            os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
                                            noobcoder.sendMessage(to, "Your bot logged in successfully!")
                                    thread = threading.Thread(target=kentod)
                                    thread.daemon = True
                                    thread.start()
                                except Exception as e:
                                    print(e)

                    elif text.lower() == "login war" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                noobcoder.sendMessage(to, "{}\nAlready Logged in Type (logout war)".format(noobcoder.getContact(sender).displayName))

                    elif text.lower() == "logout war" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                del premium['listLogin'][msg._from]
                                user = premium["myService"][msg._from]
                                os.system("screen -S {} -X quit".format(str(user)))
                                os.system('rm -rf {}'.format(str(user)))
                                time.sleep(2)
                                noobcoder.sendMessage(to, "{}\nYour Self War Logout Successfully.".format(noobcoder.getContact(sender).displayName))

                    elif text.lower() == "logout war" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                noobcoder.sendMessage(to, "{}\nType (Login war) For Login To Self war.".format(noobcoder.getContact(sender).displayName))

                    elif text.lower() == "restart war" and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                user = premium["myService"][msg._from]
                                os.system("screen -S {} -X quit".format(str(user)))
                                os.system('screen -dmS {}'.format(user))
                                os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
                                time.sleep(3)
                                noobcoder.sendMessage(to, "{}\nYour Self War Is Restarted.".format(noobcoder.getContact(sender).displayName))

#==========================================
#==========================================

                    elif text.lower() == "login kicker" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                user = premium["myService"][msg._from]
                                try:
                                    def kentod():
                                        qr = shahzi.LineGetQr("DESKTOPMAC\t7.5.0\tmacOS\t11.6")
                                        noobcoder.sendMessage(to, "Link QR: "+qr["result"]["qrlink"])
                                        noobcoder.sendImageWithURL(to, qr["result"]["qrcode"])
                                        pincode = shahzi.lineGetQrPincode(qr["result"]["session"])
                                        noobcoder.sendMessage(to, "Your Pincode: "+pincode["result"])
                                        auth = shahzi.lineGetQrAuth(qr["result"]["session"])
                                        authToken,cert = auth["result"]["accessToken"],auth["result"]["certificate"]
                                        zzz = authToken
                                        yyy = cert
                                        if msg._from not in premium['listLogin']:
                                            premium['listLogin'][msg._from] =  '%s' % user
                                            isi = "{}".format(zzz)
                                            os.system('cp -r loginkicker {}'.format(user))
                                            os.system('cd {} && echo -n "{}" > token.txt'.format(user, isi))
                                            os.system('screen -dmS {}'.format(user))
                                            os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
                                            noobcoder.sendMessage(to, "Your kicker logged in successfully!")
                                    thread = threading.Thread(target=kentod)
                                    thread.daemon = True
                                    thread.start()
                                except Exception as e:
                                    print(e)

                    elif text.lower() == "login kicker" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                noobcoder.sendMessage(to, "{}\nAlready Logged in Type (logout kicker)".format(noobcoder.getContact(sender).displayName))

                    elif text.lower() == "logout kicker" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                del premium['listLogin'][msg._from]
                                user = premium["myService"][msg._from]
                                os.system("screen -S {} -X quit".format(str(user)))
                                os.system('rm -rf {}'.format(str(user)))
                                time.sleep(2)
                                noobcoder.sendMessage(to, "{}\nYour Kicker Logout Successfully.".format(noobcoder.getContact(sender).displayName))

                    elif text.lower() == "logout kicker" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                noobcoder.sendMessage(to, "{}\nType (Login kicker) For Login To Kicker.".format(noobcoder.getContact(sender).displayName))

                    elif text.lower() == "restart kicker" and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                                user = premium["myService"][msg._from]
                                os.system("screen -S {} -X quit".format(str(user)))
                                os.system('screen -dmS {}'.format(user))
                                os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
                                time.sleep(3)
                                noobcoder.sendMessage(to, "{}\nYour Kicker Is Restarted.".format(noobcoder.getContact(sender).displayName))





#==============CMD PERAMETTERS============================
                    elif text.lower().startswith("plink "):
                      if kbkb["public"] == True:
                        if msg._from in banuser:
                            noobcoder.sendMessage(to, "User Banned By Creator")
                        else:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                plinq = shahzi.getinfo(key1)
                                lpink = "Profile Link:\n{}".format(str(plinq))
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to, str(lpink))

                    elif cmd.startswith('contact'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            proses = text.split(" ")
                            ljoin = text.replace(proses[0] + " ljoin", "")
                            if "ljoin" == proses[1] or "ljoin" + ljoin == proses[1]:
                                if "" == ljoin:
                                    ljoin = "1"
                                l = int(ljoin)
                                l -= 1
                                hasil = countLexe(to,"ljoin",l)
                                for s in hasil:
                                    noobcoder.sendContact(to, s)
                                    return
                            lkick = text.replace(proses[0] + " lkick", "")
                            if "lkick" == proses[1] or "lkick" + lkick == proses[1]:
                                if "" == lkick:
                                    lkick = "1"
                                l = int(lkick)
                                l -= 1
                                hasil = countLexe(to,"lkick",l)
                                for s in hasil:
                                    noobcoder.sendContact(to, s)
                                    return
                            linvite = text.replace(proses[0] + " linvite", "")
                            if "linvite" == proses[1] or "linvite" + linvite == proses[1]:
                                if "" == linvite:
                                    linvite = "1"
                                l = int(linvite)
                                l -= 1
                                hasil = countLexe(to,"linvite",l)
                                for s in hasil:
                                    noobcoder.sendContact(to, s)
                                    return
                            lcancel = text.replace(proses[0] + " lcancel", "")
                            if "lcancel" == proses[1] or "lcancel" + lcancel == proses[1]:
                                if "" == lcancel:
                                    lcancel = "1"
                                l = int(lcancel)
                                l -= 1
                                hasil = countLexe(to,"lcancel",l)
                                for s in hasil:
                                    noobcoder.sendContact(to, s)
                                    return
                            lleave = text.replace(proses[0] + " lleave", "")
                            if "lleave" == proses[1] or "lleave" + lleave == proses[1]:
                                if "" == lleave:
                                    lleave = "1"
                                l = int(lleave)
                                l -= 1
                                hasil = countLexe(to,"lleave",l)
                                for s in hasil:
                                    noobcoder.sendContact(to, s)
                                    return
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                noobcoder.sendContact(to, target)

                    elif cmd.startswith('invite'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            proses = text.split(" ")
                            ljoin = text.replace(proses[0] + " ljoin", "")
                            if "ljoin" == proses[1] or "ljoin" + ljoin == proses[1]:
                                if "" == ljoin:
                                    ljoin = "1"
                                l = int(ljoin)
                                l -= 1
                                hasil = countLexe(to,"ljoin",l)
                                for s in hasil:
                                    try:
                                        noobcoder.findAndAddContactsByMid(s) 
                                    except:
                                        noobcoder.sendMessage(to,"sorry i limit add")
                                        break
                                noobcoder.inviteIntoGroup(to,[s])
                                return
                            lkick = text.replace(proses[0] + " lkick", "")
                            if "lkick" == proses[1] or "lkick" + lkick == proses[1]:
                                if "" == lkick:
                                    lkick = "1"
                                l = int(lkick)
                                l -= 1
                                hasil = countLexe(to,"lkick",l)
                                for s in hasil:
                                    try:
                                        noobcoder.findAndAddContactsByMid(s) 
                                    except:
                                        noobcoder.sendMessage(to,"sorry i limit add")
                                        break
                                noobcoder.inviteIntoGroup(to,[s])
                                return
                            linvite = text.replace(proses[0] + " linvite", "")
                            if "linvite" == proses[1] or "linvite" + linvite == proses[1]:
                                if "" == linvite:
                                    linvite = "1"
                                l = int(linvite)
                                l -= 1
                                hasil = countLexe(to,"linvite",l)
                                for s in hasil:
                                    try:
                                        noobcoder.findAndAddContactsByMid(s) 
                                    except:
                                        noobcoder.sendMessage(to,"sorry i limit add")
                                        break
                                noobcoder.inviteIntoGroup(to,[s])
                                return
                            lcancel = text.replace(proses[0] + " lcancel", "")
                            if "lcancel" == proses[1] or "lcancel" + lcancel == proses[1]:
                                if "" == lcancel:
                                    lcancel = "1"
                                l = int(lcancel)
                                l -= 1
                                hasil = countLexe(to,"lcancel",l)
                                for s in hasil:
                                    try:
                                        noobcoder.findAndAddContactsByMid(s) 
                                    except:
                                        noobcoder.sendMessage(to,"sorry i limit add")
                                        break
                                noobcoder.inviteIntoGroup(to,[s])
                                return
                            lleave = text.replace(proses[0] + " lleave", "")
                            if "lleave" == proses[1] or "lleave" + lleave == proses[1]:
                                if "" == lleave:
                                    lleave = "1"
                                l = int(lleave)
                                l -= 1
                                hasil = countLexe(to,"lleave",l)
                                for s in hasil:
                                    try:
                                        noobcoder.findAndAddContactsByMid(s) 
                                    except:
                                        noobcoder.sendMessage(to,"sorry i limit add")
                                        break
                                noobcoder.inviteIntoGroup(to,[s])
                                return
                            lcon = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                                if "" == lcon:
                                    lcon = "1"
                                l = int(lcon)
                                l -= 1
                                hasil = countLexe(to,"lcon",l)
                                for s in hasil:
                                    try:
                                        noobcoder.findAndAddContactsByMid(s) 
                                    except:
                                        noobcoder.sendMessage(to,"sorry i limit add")
                                        break
                                noobcoder.inviteIntoGroup(to,[s])
                                return
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                try:
                                    noobcoder.findAndAddContactsByMid(target) 
                                except:
                                    noobcoder.sendMessage(to,"sorry i limit add")
                                    break
                            noobcoder.inviteIntoGroup(to,[target])

                    elif cmd.startswith('cancel'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            proses = text.split(" ")
                            ljoin = text.replace(proses[0] + " ljoin", "")
                            if "ljoin" == proses[1] or "ljoin" + ljoin == proses[1]:
                                if "" == ljoin:
                                    ljoin = "1"
                                l = int(ljoin)
                                l -= 1
                                hasil = countLexe(to,"ljoin",l)
                                for s in hasil:
                                    try:
                                        noobcoder.cancelGroupInvitation(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"cancel on limit.")
                                        return
                            lkick = text.replace(proses[0] + " lkick", "")
                            if "lkick" == proses[1] or "lkick" + lkick == proses[1]:
                                if "" == lkick:
                                    lkick = "1"
                                l = int(lkick)
                                l -= 1
                                hasil = countLexe(to,"lkick",l)
                                for s in hasil:
                                    try:
                                        noobcoder.cancelGroupInvitation(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"cancel on limit.")
                                        return
                            linvite = text.replace(proses[0] + " linvite", "")
                            if "linvite" == proses[1] or "linvite" + linvite == proses[1]:
                                if "" == linvite:
                                    linvite = "1"
                                l = int(linvite)
                                l -= 1
                                hasil = countLexe(to,"linvite",l)
                                for s in hasil:
                                    try:
                                        noobcoder.cancelGroupInvitation(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"cancel on limit.")
                                        return
                            lcancel = text.replace(proses[0] + " lcancel", "")
                            if "lcancel" == proses[1] or "lcancel" + lcancel == proses[1]:
                                if "" == lcancel:
                                    lcancel = "1"
                                l = int(lcancel)
                                l -= 1
                                hasil = countLexe(to,"lcancel",l)
                                for s in hasil:
                                    try:
                                        noobcoder.cancelGroupInvitation(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"cancel on limit.")
                                        return
                            lleave = text.replace(proses[0] + " lleave", "")
                            if "lleave" == proses[1] or "lleave" + lleave == proses[1]:
                                if "" == lleave:
                                    lleave = "1"
                                l = int(lleave)
                                l -= 1
                                hasil = countLexe(to,"lleave",l)
                                for s in hasil:
                                    try:
                                        noobcoder.cancelGroupInvitation(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"cancel on limit.")
                                        return
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                try:
                                    noobcoder.cancelGroupInvitation(to, [target])
                                except:
                                    noobcoder.sendMessage(to,"cancel on limit.")

                    elif cmd.startswith('kick'):
                        if msg._from in creator or msg._from in seller or msg._from in buyer:
                            proses = text.split(" ")
                            ljoin = text.replace(proses[0] + " ljoin", "")
                            if "ljoin" == proses[1] or "ljoin" + ljoin == proses[1]:
                                if "" == ljoin:
                                    ljoin = "1"
                                l = int(ljoin)
                                l -= 1
                                hasil = countLexe(to,"ljoin",l)
                                for s in hasil:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"kick on limit.")
                                        return
                            lkick = text.replace(proses[0] + " lkick", "")
                            if "lkick" == proses[1] or "lkick" + lkick == proses[1]:
                                if "" == lkick:
                                    lkick = "1"
                                l = int(lkick)
                                l -= 1
                                hasil = countLexe(to,"lkick",l)
                                for s in hasil:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"kick on limit.")
                                        return
                            linvite = text.replace(proses[0] + " linvite", "")
                            if "linvite" == proses[1] or "linvite" + linvite == proses[1]:
                                if "" == linvite:
                                    linvite = "1"
                                l = int(linvite)
                                l -= 1
                                hasil = countLexe(to,"linvite",l)
                                for s in hasil:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"kick on limit.")
                                        return
                            lcancel = text.replace(proses[0] + " lcancel", "")
                            if "lcancel" == proses[1] or "lcancel" + lcancel == proses[1]:
                                if "" == lcancel:
                                    lcancel = "1"
                                l = int(lcancel)
                                l -= 1
                                hasil = countLexe(to,"lcancel",l)
                                for s in hasil:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"kick on limit.")
                                        return
                            lcon = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                                if "" == lcon:
                                    lcon = "1"
                                l = int(lcon)
                                l -= 1
                                hasil = countLexe(to,"lcon",l)
                                for s in hasil:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"kick on limit.")
                                        return
                            lleave = text.replace(proses[0] + " lleave", "")
                            if "lleave" == proses[1] or "lleave" + lleave == proses[1]:
                                if "" == lleave:
                                    lleave = "1"
                                l = int(lleave)
                                l -= 1
                                hasil = countLexe(to,"lleave",l)
                                for s in hasil:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [s])
                                    except:
                                        noobcoder.sendMessage(to,"kick on limit.")
                                        return
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                try:
                                    noobcoder.kickoutFromGroup(to, [target])
                                except:
                                    noobcoder.sendMessage(to,"kick on limit.")

                    elif text.lower().startswith('mid'):
                        if kbkb["public"] == True:
                            proses = text.split(" ")
                            lcon = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + lcon == proses[1]:
                                if "" == lcon:
                                    lcon = "1"
                                l = int(lcon)
                                l -= 1
                                hasil = countLexe(to,"lcon",l)
                                numb = 0
                                for s in hasil:
                                    numb += 1
                                    tx = "{}. {}\n{}\n".format(str(numb),noobcoder.getContact(s).displayName,s)
                                noobcoder.sendMessage(to, tx)





#==========================================


        
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
    
def run():
    while True:
        try:
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(noobcoderBot(op))
                   noobcoderPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
            
if __name__ == "__main__":
    run()
